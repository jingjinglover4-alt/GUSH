import http from './http'

/**
 * 库存流水
 * params: { product, machine, channel, kind, since, until, page, page_size }
 *   kind 支持: inbound / restock / dispense / return / adjust
 *   （restock 和 return 自动展开 out+in 两条）
 */
export function listStockMovements(params = {}) {
  return http.get('/stock-movements/', { params })
}

/** 货道回库 */
export function returnChannelToWarehouse(channelId, payload = {}) {
  // payload: { quantity?, note? }  quantity 不传则全部回库
  return http.post(`/devices/channels/${channelId}/return_to_warehouse/`, payload)
}
