/**
 * 设备 / 货道 API 封装
 */
import http from './http'

// ----- 设备 -----
export function listMachines(params = {}) {
  return http.get('/devices/machines/', { params })
}

// Phase 4.1 健康看板
export function deviceHealthOverview() {
  return http.get('/devices/health/overview/')
}

export function getMachine(id) {
  return http.get(`/devices/machines/${id}/`)
}

export function createMachine(data) {
  return http.post('/devices/machines/', data)
}

export function updateMachine(id, data) {
  return http.patch(`/devices/machines/${id}/`, data)
}

export function deleteMachine(id) {
  return http.delete(`/devices/machines/${id}/`)
}

export function machineDispenses(id) {
  return http.get(`/devices/machines/${id}/dispenses/`)
}

export function machineFaults(id, openOnly = false) {
  return http.get(`/devices/machines/${id}/faults/`, { params: openOnly ? { open: 1 } : {} })
}

// ----- 货道 -----
export function listChannels(machineId) {
  return http.get('/devices/channels/', { params: { machine: machineId } })
}

export function restockChannel(channelId, payload) {
  return http.post(`/devices/channels/${channelId}/restock/`, payload)
}

export function dispenseChannel(channelId) {
  return http.post(`/devices/channels/${channelId}/dispense/`, {})
}

export function setChannelFault(channelId, fault, message = '') {
  return http.post(`/devices/channels/${channelId}/fault/`, { fault, message })
}

export function updateChannel(channelId, data) {
  return http.patch(`/devices/channels/${channelId}/`, data)
}

// ----- 远程指令下发（阶段 3：WebSocket）-----
export function sendCommand(machineId, payload) {
  return http.post(`/devices/machines/${machineId}/send_command/`, payload)
}

/**
 * 批量补货 / 一键补满
 * payload: { channel_ids?, product_id?, max_per_channel?, note? }
 *  - 不传 product/channel_ids = 巡补已绑货道
 *  - 传 product_id + channel_ids = 批量投放此礼品到指定货道
 */
export function bulkRestockMachine(machineId, payload = {}) {
  return http.post(`/devices/machines/${machineId}/bulk_restock/`, payload)
}

