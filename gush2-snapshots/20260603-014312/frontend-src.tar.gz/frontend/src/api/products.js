import http from './http'

export function listProducts(params = {}) {
  return http.get('/products/', { params })
}

export function getProduct(id) {
  return http.get(`/products/${id}/`)
}

export function createProduct(payload) {
  // FormData 支持图片上传
  return http.post('/products/', payload)
}

export function updateProduct(id, payload) {
  return http.patch(`/products/${id}/`, payload)
}

export function deleteProduct(id) {
  return http.delete(`/products/${id}/`)
}

export function inboundStock(id, payload) {
  // payload: { quantity, note }
  return http.post(`/products/${id}/inbound/`, payload)
}
