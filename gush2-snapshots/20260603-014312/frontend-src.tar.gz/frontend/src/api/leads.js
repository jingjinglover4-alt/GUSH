/**
 * 用户获客列表 / 画像 API（Phase 3.2）
 */
import http from './http'

export function listLeads(projectId, params = {}) {
  return http.get(`/projects/${projectId}/leads/`, { params })
}

export function leadsSummary(projectId) {
  return http.get(`/projects/${projectId}/leads/summary/`)
}

export async function exportLeadsCsv(projectId, params = {}) {
  const resp = await http.get(`/projects/${projectId}/leads/export/`, {
    params, responseType: 'blob'
  })
  const blob = resp instanceof Blob ? resp : new Blob([resp])
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = `leads-${projectId}-${new Date().toISOString().slice(0, 10)}.csv`
  document.body.appendChild(link)
  link.click()
  link.remove()
  setTimeout(() => URL.revokeObjectURL(link.href), 1000)
}
