import http from './http'

export function listOperationLogs(params = {}) {
  return http.get('/operations/logs/', { params })
}
