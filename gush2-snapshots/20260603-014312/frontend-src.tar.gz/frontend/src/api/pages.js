/**
 * 页面装修 API（项目维度）
 */
import http from './http'

// ---- 主题 ----
export function getProjectTheme(projectId) {
  return http.get(`/projects/${projectId}/theme/`)
}

/**
 * 更新主题。支持两种形态：
 *   updateProjectTheme(id, { brand_color: '#xxx' })  → JSON
 *   updateProjectTheme(id, formData)                 → 含文件的 FormData
 */
export function updateProjectTheme(projectId, data) {
  // FormData 让 axios 自动设置 Content-Type（含 boundary）
  return http.patch(`/projects/${projectId}/theme/`, data)
}

// ---- H5 ----
export function getProjectH5(projectId) {
  return http.get(`/projects/${projectId}/h5/`)
}
export function updateProjectH5(projectId, data) {
  return http.patch(`/projects/${projectId}/h5/`, data)
}
export function publishProjectH5(projectId, note = '') {
  return http.post(`/projects/${projectId}/h5/publish/`, { note })
}

// ---- LED 大屏页 ----
export function getProjectLed(projectId) {
  return http.get(`/projects/${projectId}/led/`)
}
export function updateProjectLed(projectId, data) {
  return http.patch(`/projects/${projectId}/led/`, data)
}
export function publishProjectLed(projectId, note = '') {
  return http.post(`/projects/${projectId}/led/publish/`, { note })
}

// ---- 版本历史 ----
export function listPageVersions(projectId, params = {}) {
  return http.get(`/projects/${projectId}/page-versions/`, { params })
}
// ---- Phase 2.2 漏斗统计 ----
export function getProjectFunnel(projectId, days = 14) {
  return http.get(`/projects/${projectId}/stats/funnel/`, { params: { days } })
}

// ---- Phase 2.3 A/B 实验 ----
export function getExperiment(projectId) {
  return http.get(`/projects/${projectId}/experiment/`)
}
export function createExperiment(projectId, data) {
  return http.post(`/projects/${projectId}/experiment/`, data)
}
export function deleteExperiment(projectId) {
  return http.delete(`/projects/${projectId}/experiment/`)
}
export function updateExperimentVariant(projectId, variantId, data) {
  return http.patch(`/projects/${projectId}/experiment/variants/${variantId}/`, data)
}
export function transitionExperiment(projectId, to, extra = {}) {
  return http.post(`/projects/${projectId}/experiment/transition/`, { to, ...extra })
}
export function getExperimentStats(projectId) {
  return http.get(`/projects/${projectId}/experiment/stats/`)
}

// ---- Phase 2.5 CSV 导出（走 axios 拿 token，blob 触发下载） ----
async function downloadBlob(url, filename) {
  const resp = await http.get(url, { responseType: 'blob' })
  // http 拦截器返回的是 resp.data；这里就是 Blob 本身
  const blob = resp instanceof Blob ? resp : new Blob([resp])
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = filename
  document.body.appendChild(link)
  link.click()
  link.remove()
  setTimeout(() => URL.revokeObjectURL(link.href), 1000)
}

export function exportFunnelCsv(projectId, days = 30) {
  const today = new Date().toISOString().slice(0, 10)
  return downloadBlob(
    `/projects/${projectId}/stats/funnel/export/?days=${days}`,
    `funnel-${projectId}-${days}d-${today}.csv`
  )
}

export function exportExperimentCsv(projectId) {
  const today = new Date().toISOString().slice(0, 10)
  return downloadBlob(
    `/projects/${projectId}/experiment/export/`,
    `experiment-${projectId}-${today}.csv`
  )
}

/**
 * 回滚到某个历史版本。
 * options: { include_theme: true, publish: false }
 *  - publish=false (默认)：仅恢复到草稿，需手动再点发布
 *  - publish=true：一次性回滚+发布，写一条新版本号
 */
export function restorePageVersion(projectId, versionId, options = {}) {
  return http.post(
    `/projects/${projectId}/page-versions/${versionId}/restore/`,
    {
      include_theme: options.include_theme !== false,
      publish: !!options.publish,
    }
  )
}

// ---- 通用图片上传 ----
export function uploadBlockImage(projectId, file) {
  // file 是 File 对象，不需要提前包 FormData
  const fd = new FormData()
  fd.append('file', file)
  return http.post(`/projects/${projectId}/upload/`, fd)
}

// ---- 设备级覆盖（Phase 1.7） ----
export function getDeviceOverride(machineId) {
  return http.get(`/devices/${machineId}/page-override/`)
}
export function updateDeviceOverride(machineId, data) {
  return http.patch(`/devices/${machineId}/page-override/`, data)
}
export function clearDeviceOverride(machineId) {
  return http.delete(`/devices/${machineId}/page-override/`)
}
