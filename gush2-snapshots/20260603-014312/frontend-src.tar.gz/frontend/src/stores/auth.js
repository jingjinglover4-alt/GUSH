/**
 * 认证状态 - token 持久化到 localStorage
 */
import { defineStore } from 'pinia'
import { login as loginApi, fetchMe } from '@/api/auth'

const LS_ACCESS = 'gush2_access'
const LS_REFRESH = 'gush2_refresh'
const LS_USER = 'gush2_user'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    accessToken: localStorage.getItem(LS_ACCESS) || '',
    refreshToken: localStorage.getItem(LS_REFRESH) || '',
    user: JSON.parse(localStorage.getItem(LS_USER) || 'null')
  }),

  getters: {
    isLoggedIn: (state) => !!state.accessToken,
    roleLabel: (state) => state.user?.role_display || ''
  },

  actions: {
    async login(username, password) {
      const data = await loginApi(username, password)
      this.accessToken = data.access
      this.refreshToken = data.refresh
      this.user = data.user
      localStorage.setItem(LS_ACCESS, data.access)
      localStorage.setItem(LS_REFRESH, data.refresh)
      localStorage.setItem(LS_USER, JSON.stringify(data.user))
      return data
    },

    async refreshMe() {
      this.user = await fetchMe()
      localStorage.setItem(LS_USER, JSON.stringify(this.user))
    },

    clear() {
      this.accessToken = ''
      this.refreshToken = ''
      this.user = null
      localStorage.removeItem(LS_ACCESS)
      localStorage.removeItem(LS_REFRESH)
      localStorage.removeItem(LS_USER)
    }
  }
})
