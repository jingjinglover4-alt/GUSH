/**
 * 系统配置 store - 缓存 root_domain 等只读全局信息
 */
import { defineStore } from 'pinia'
import http from '@/api/http'

export const useSystemStore = defineStore('system', {
  state: () => ({
    rootDomain: 'gush.cdgushai.com',
    useHttps: false,
    loaded: false,
  }),
  getters: {
    scheme: (s) => (s.useHttps ? 'https' : 'http'),
    /** 拼一个 H5 落地页 URL（项目级） */
    h5Url: (s) => (projectId, machineId = '') => {
      // H5 一般用项目 ID 路径走主域（任何子域都可访问）
      const base = `${s.scheme}://${s.rootDomain}/p/${projectId}/`
      return machineId ? `${base}?machine_id=${machineId}` : base
    },
    /** 拼 LED 大屏 URL（设备级） */
    ledUrl: (s) => (subdomain) => {
      // 子域名直接根路径即可（中间件会自动渲染该机器 LED）
      return `${s.scheme}://${subdomain}.${s.rootDomain}/`
    },
    /** 也可以用兜底地址：/led/{machine_id}/ */
    ledFallbackUrl: (s) => (machineId) => {
      return `${s.scheme}://${s.rootDomain}/led/${machineId}/`
    },
  },
  actions: {
    async load() {
      if (this.loaded) return
      try {
        const r = await http.get('/system/info/')
        this.rootDomain = r.root_domain || this.rootDomain
        this.useHttps = !!r.use_https
        this.loaded = true
      } catch (e) {
        // 静默：留默认值
      }
    },
  },
})
