<template>
  <div class="stock-page">
    <!-- 筛选条 -->
    <el-card class="filter-card">
      <div class="filters">
        <el-select v-model="filters.kind" placeholder="事件类型" clearable style="width: 140px">
          <el-option label="入库" value="inbound" />
          <el-option label="补货" value="restock" />
          <el-option label="派样" value="dispense" />
          <el-option label="回库" value="return" />
          <el-option label="人工调整" value="adjust" />
        </el-select>
        <el-select
          v-model="filters.product"
          placeholder="按礼品筛选"
          filterable clearable
          style="width: 220px"
        >
          <el-option
            v-for="p in productOpts"
            :key="p.id"
            :label="`${p.sku} · ${p.name}`"
            :value="p.id"
          />
        </el-select>
        <el-select
          v-model="filters.machine"
          placeholder="按设备筛选"
          filterable clearable
          style="width: 220px"
        >
          <el-option
            v-for="m in machineOpts"
            :key="m.id"
            :label="`${m.machine_id} · ${m.name}`"
            :value="m.id"
          />
        </el-select>
        <el-date-picker
          v-model="dateRange"
          type="daterange"
          range-separator="—"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          style="width: 280px"
          value-format="YYYY-MM-DD"
        />
        <el-button type="primary" @click="refresh">查询</el-button>
        <el-button @click="reset">重置</el-button>
        <span class="spacer" />
        <el-button :icon="Refresh" circle @click="refresh" />
      </div>
    </el-card>

    <!-- 表格 -->
    <el-card class="table-card">
      <el-table :data="rows" v-loading="loading" stripe size="small" border>
        <el-table-column label="时间" prop="created_at" width="170" />
        <el-table-column label="事件" width="140">
          <template #default="{ row }">
            <el-tag :type="kindTag(row.kind)" size="small">{{ row.kind_display }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="礼品" min-width="180">
          <template #default="{ row }">
            <div>{{ row.product_name }}</div>
            <div class="muted">{{ row.product_sku }}</div>
          </template>
        </el-table-column>
        <el-table-column label="数量" width="80" align="center">
          <template #default="{ row }">×{{ row.quantity }}</template>
        </el-table-column>
        <el-table-column label="仓库变动" width="110" align="center">
          <template #default="{ row }">
            <span :class="deltaClass(row.warehouse_delta)">
              {{ formatDelta(row.warehouse_delta) }}
            </span>
            <div class="muted" v-if="row.warehouse_after !== null">余 {{ row.warehouse_after }}</div>
          </template>
        </el-table-column>
        <el-table-column label="货道变动" width="110" align="center">
          <template #default="{ row }">
            <span :class="deltaClass(row.channel_delta)">
              {{ formatDelta(row.channel_delta) }}
            </span>
            <div class="muted" v-if="row.channel_stock_after !== null">余 {{ row.channel_stock_after }}</div>
          </template>
        </el-table-column>
        <el-table-column label="设备/货道" min-width="180">
          <template #default="{ row }">
            <span v-if="!row.machine_code" class="muted">—</span>
            <template v-else>
              <el-link type="primary" @click="$router.push(`/devices/${row.machine}`)">
                {{ row.machine_code }}
              </el-link>
              <span v-if="row.channel_code" class="muted"> · {{ row.channel_code }}</span>
            </template>
          </template>
        </el-table-column>
        <el-table-column label="兑换码" width="120">
          <template #default="{ row }">
            <span v-if="row.redeem_code_str">{{ row.redeem_code_str }}</span>
            <span v-else class="muted">—</span>
          </template>
        </el-table-column>
        <el-table-column label="来源" width="100">
          <template #default="{ row }">
            <span class="muted">{{ row.source || '—' }}</span>
          </template>
        </el-table-column>
        <el-table-column label="操作人" width="100">
          <template #default="{ row }">
            <span :class="row.operator_name ? '' : 'muted'">
              {{ row.operator_name || '系统' }}
            </span>
          </template>
        </el-table-column>
        <el-table-column label="备注" min-width="120" show-overflow-tooltip prop="note" />
      </el-table>

      <div class="pager">
        <el-pagination
          v-model:current-page="page"
          v-model:page-size="pageSize"
          :page-sizes="[20, 50, 100, 200]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          background
          @current-change="load"
          @size-change="load"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, computed, watch } from 'vue'
import { Refresh } from '@element-plus/icons-vue'
import { listStockMovements } from '@/api/stock'
import { listProducts } from '@/api/products'
import { listMachines } from '@/api/devices'

const loading = ref(false)
const rows = ref([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(50)

const filters = reactive({
  kind: '',
  product: null,
  machine: null,
})
const dateRange = ref([])

const productOpts = ref([])
const machineOpts = ref([])

async function loadOpts() {
  try {
    const p = await listProducts({ page_size: 200 })
    productOpts.value = Array.isArray(p) ? p : (p.results || [])
  } catch {}
  try {
    const m = await listMachines()
    machineOpts.value = Array.isArray(m) ? m : (m.results || [])
  } catch {}
}

async function load() {
  loading.value = true
  const params = {
    page: page.value,
    page_size: pageSize.value,
  }
  if (filters.kind) params.kind = filters.kind
  if (filters.product) params.product = filters.product
  if (filters.machine) params.machine = filters.machine
  if (dateRange.value?.length === 2) {
    params.since = dateRange.value[0] + 'T00:00:00'
    params.until = dateRange.value[1] + 'T23:59:59'
  }
  try {
    const resp = await listStockMovements(params)
    rows.value = resp.results || []
    total.value = resp.count || 0
  } finally {
    loading.value = false
  }
}

function refresh() {
  page.value = 1
  load()
}

function reset() {
  filters.kind = ''
  filters.product = null
  filters.machine = null
  dateRange.value = []
  refresh()
}

function kindTag(kind) {
  if (kind === 'inbound') return 'success'
  if (kind === 'restock_in' || kind === 'restock_out') return 'primary'
  if (kind === 'dispense') return 'warning'
  if (kind === 'return_in' || kind === 'return_out') return 'info'
  return ''
}
function deltaClass(d) {
  if (d > 0) return 'pos'
  if (d < 0) return 'neg'
  return 'zero'
}
function formatDelta(d) {
  if (d > 0) return '+' + d
  if (d < 0) return String(d)
  return '—'
}

onMounted(() => {
  loadOpts()
  load()
})
</script>

<style lang="scss" scoped>
.stock-page {
  .filter-card { margin-bottom: 12px; }
  .filters {
    display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
    .spacer { flex: 1; }
  }
  .table-card {
    .muted { color: #909399; font-size: 12px; }
    .pos { color: #67c23a; font-weight: 600; }
    .neg { color: #f56c6c; font-weight: 600; }
    .zero { color: #909399; }
    .pager { display: flex; justify-content: flex-end; margin-top: 12px; }
  }
}
</style>
