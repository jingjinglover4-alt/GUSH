<template>
  <el-result
    icon="info"
    :title="$route.meta.title"
    :sub-title="`该模块计划在阶段 ${$route.meta.stage} 实现`"
  >
    <template #extra>
      <el-button type="primary" @click="$router.push('/dashboard')">
        返回仪表盘
      </el-button>
    </template>
  </el-result>
</template>
