<template>
  <div class="dashboard" v-loading="loading">
    <!-- 数据卡片 -->
    <el-row :gutter="16">
      <el-col v-for="card in cards" :key="card.label" :xs="12" :sm="8" :md="4">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-label">{{ card.label }}</div>
          <div class="stat-value" :style="{ color: card.color }">{{ card.value }}</div>
        </el-card>
      </el-col>
    </el-row>

    <!-- Phase 4.2 今日漏斗 + 项目/实验状态 -->
    <el-row :gutter="16" style="margin-top: 16px">
      <el-col :xs="24" :md="14">
        <el-card class="stat-card" shadow="hover" header="今日漏斗">
          <div class="funnel-row">
            <div class="funnel-step">
              <div class="funnel-step-label">H5 访问</div>
              <div class="funnel-step-value">{{ data.today_funnel?.h5_visits ?? 0 }}</div>
            </div>
            <div class="funnel-arrow">→</div>
            <div class="funnel-step">
              <div class="funnel-step-label">领码</div>
              <div class="funnel-step-value" style="color:#67c23a">{{ data.today_funnel?.claims ?? 0 }}</div>
              <div class="funnel-step-rate">{{ funnelRate('h5_visits', 'claims') }}%</div>
            </div>
            <div class="funnel-arrow">→</div>
            <div class="funnel-step">
              <div class="funnel-step-label">核销</div>
              <div class="funnel-step-value" style="color:#e6a23c">{{ data.today_funnel?.redeems ?? 0 }}</div>
              <div class="funnel-step-rate">{{ funnelRate('claims', 'redeems') }}%</div>
            </div>
            <div class="funnel-spacer" />
            <div class="funnel-step">
              <div class="funnel-step-label">LED 访问</div>
              <div class="funnel-step-value">{{ data.today_funnel?.led_visits ?? 0 }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="12" :md="5">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-label">运行中项目 / 草稿</div>
          <div class="stat-value-sm">
            <span style="color:#67c23a">{{ data.project?.running ?? 0 }}</span>
            <span class="sep">/</span>
            <span style="color:#909399">{{ data.project?.draft ?? 0 }}</span>
          </div>
          <div class="stat-sub">
            <router-link to="/projects" class="link">查看项目 →</router-link>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="12" :md="5">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-label">运行中实验 / 暂停</div>
          <div class="stat-value-sm">
            <span style="color:#409eff">{{ data.experiment?.running ?? 0 }}</span>
            <span class="sep">/</span>
            <span style="color:#909399">{{ data.experiment?.stopped ?? 0 }}</span>
          </div>
          <div class="stat-sub">
            <span v-if="data.face?.today">今日画像 {{ data.face.today }} 条</span>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 图表区 -->
    <el-row :gutter="16" style="margin-top: 16px">
      <el-col :xs="24" :md="14">
        <el-card class="chart-card" header="近 7 日出货趋势">
          <div ref="trendRef" class="chart"></div>
        </el-card>
      </el-col>
      <el-col :xs="24" :md="10">
        <el-card class="chart-card" header="设备状态分布">
          <div ref="deviceRef" class="chart"></div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="16" style="margin-top: 16px">
      <el-col :xs="24" :md="12">
        <el-card class="chart-card" header="项目兑换排行 Top 5">
          <div ref="rankRef" class="chart"></div>
        </el-card>
      </el-col>
      <el-col :xs="24" :md="12">
        <el-card class="chart-card" header="库存预警货道">
          <el-table :data="data.low_channels || []" size="small" stripe height="280">
            <el-table-column prop="machine_id" label="机器" width="120" />
            <el-table-column prop="channel_code" label="货道" width="80" />
            <el-table-column prop="product" label="商品" />
            <el-table-column label="库存" width="100">
              <template #default="{ row }">
                {{ row.current_stock }} / {{ row.capacity }}
              </template>
            </el-table-column>
            <el-table-column prop="status" label="状态" width="80">
              <template #default="{ row }">
                <el-tag :type="row.status === 'empty' ? 'danger' : 'warning'" size="small">
                  {{ row.status === 'empty' ? '空' : '低' }}
                </el-tag>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>

    <!-- 设备地图 -->
    <el-row :gutter="16" style="margin-top: 16px">
      <el-col :span="24">
        <el-card class="chart-card" header="设备地图">
          <div ref="mapRef" class="map-container"></div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onBeforeUnmount, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import * as echarts from 'echarts'
import { fetchDashboard } from '@/api/stats'

const loading = ref(false)
const data = reactive({
  device: {}, channel: {}, dispense: {}, redeem_code: {},
  project_rank: [], low_channels: [],
  // Phase 4.2 新增
  today_funnel: { h5_visits: 0, led_visits: 0, claims: 0, redeems: 0 },
  project: { running: 0, draft: 0 },
  experiment: { running: 0, stopped: 0 },
  face: { today: 0, by_gender: {} },
  device_locations: [],
})

function funnelRate(numKey, denKey) {
  const num = data.today_funnel?.[denKey] ?? 0
  const den = data.today_funnel?.[numKey] ?? 0
  return den > 0 ? Math.round(num / den * 100 * 100) / 100 : 0
}

const trendRef = ref(null)
const deviceRef = ref(null)
const rankRef = ref(null)
const mapRef = ref(null)
let trendChart = null
let deviceChart = null
let rankChart = null
let mapInstance = null
let mapMarkers = []
let leafletLoaded = false

const cards = computed(() => [
  { label: '设备总数', value: data.device.total ?? 0, color: '#409eff' },
  { label: '在线设备', value: data.device.online ?? 0, color: '#67c23a' },
  { label: '离线设备', value: data.device.offline ?? 0, color: '#909399' },
  { label: '故障设备', value: data.device.fault ?? 0, color: '#f56c6c' },
  { label: '今日出货', value: data.dispense.today ?? 0, color: '#e6a23c' },
  { label: '兑换码已用', value: `${data.redeem_code.used ?? 0}/${data.redeem_code.total ?? 0}`, color: '#a07cfe' }
])

const darkTheme = {
  backgroundColor: 'transparent',
  textStyle: { color: '#c0c4cc' }
}

function renderTrend() {
  if (!trendRef.value) return
  trendChart ||= echarts.init(trendRef.value, null, { renderer: 'canvas' })
  const trend = data.dispense.trend || []
  trendChart.setOption({
    ...darkTheme,
    tooltip: { trigger: 'axis' },
    grid: { top: 24, left: 40, right: 16, bottom: 30 },
    xAxis: {
      type: 'category',
      data: trend.map(t => t.date.slice(5)),
      axisLine: { lineStyle: { color: '#444' } }
    },
    yAxis: { type: 'value', splitLine: { lineStyle: { color: '#2a3142' } } },
    series: [{
      type: 'line',
      smooth: true,
      data: trend.map(t => t.count),
      areaStyle: { color: 'rgba(64,158,255,0.2)' },
      lineStyle: { color: '#409eff' },
      itemStyle: { color: '#409eff' }
    }]
  })
}

function renderDevice() {
  if (!deviceRef.value) return
  deviceChart ||= echarts.init(deviceRef.value)
  const d = data.device
  deviceChart.setOption({
    ...darkTheme,
    tooltip: { trigger: 'item' },
    legend: { bottom: 0, textStyle: { color: '#c0c4cc' } },
    series: [{
      type: 'pie',
      radius: ['45%', '70%'],
      data: [
        { value: d.online ?? 0, name: '在线', itemStyle: { color: '#67c23a' } },
        { value: d.offline ?? 0, name: '离线', itemStyle: { color: '#909399' } },
        { value: d.fault ?? 0, name: '故障', itemStyle: { color: '#f56c6c' } }
      ],
      label: { color: '#c0c4cc' }
    }]
  })
}

function renderRank() {
  if (!rankRef.value) return
  rankChart ||= echarts.init(rankRef.value)
  const items = data.project_rank || []
  rankChart.setOption({
    ...darkTheme,
    tooltip: { trigger: 'axis' },
    grid: { top: 16, left: 120, right: 24, bottom: 24 },
    xAxis: { type: 'value', splitLine: { lineStyle: { color: '#2a3142' } } },
    yAxis: {
      type: 'category',
      data: items.map(i => i.name).reverse(),
      axisLine: { lineStyle: { color: '#444' } }
    },
    series: [{
      type: 'bar',
      data: items.map(i => i.used).reverse(),
      itemStyle: { color: '#a07cfe' },
      barWidth: 16
    }]
  })
}

async function load() {
  loading.value = true
  try {
    const res = await fetchDashboard()
    Object.assign(data, res)
    await nextTick()
    renderTrend(); renderDevice(); renderRank()
    renderMap()
  } catch (e) {
    ElMessage.error('加载仪表盘失败：' + (e?.response?.data?.detail || e.message))
  } finally {
    loading.value = false
  }
}

function statusTag(s) {
  return ({ online: 'success', offline: 'info', fault: 'danger' })[s] || 'info'
}
function statusLabel(s) {
  return ({ online: '在线', offline: '离线', fault: '故障' })[s] || s
}

async function renderMap() {
  if (!data.device_locations?.length) return
  if (!mapRef.value) return

  if (!leafletLoaded) {
    // 动态加载 Leaflet CSS + JS
    const link = document.createElement('link')
    link.rel = 'stylesheet'
    link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'
    document.head.appendChild(link)
    await new Promise((resolve, reject) => {
      const script = document.createElement('script')
      script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'
      script.onload = resolve
      script.onerror = reject
      document.body.appendChild(script)
    })
    leafletLoaded = true
  }

  const L = window.L
  if (!L) return

  // 清理旧地图
  if (mapInstance) {
    mapMarkers.forEach(m => mapInstance.removeLayer(m))
    mapMarkers = []
    mapInstance.remove()
    mapInstance = null
  }

  // 计算中心点
  const locs = data.device_locations
  const sumLat = locs.reduce((s, d) => s + parseFloat(d.latitude), 0)
  const sumLng = locs.reduce((s, d) => s + parseFloat(d.longitude), 0)
  const center = [sumLat / locs.length, sumLng / locs.length]

  mapInstance = L.map(mapRef.value, { zoomControl: true }).setView(center, 12)

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors',
    maxZoom: 18,
  }).addTo(mapInstance)

  locs.forEach(d => {
    const lat = parseFloat(d.latitude)
    const lng = parseFloat(d.longitude)
    if (!lat || !lng) return

    const color = d.status === 'online' ? '#67c23a'
      : d.status === 'fault' ? '#f56c6c' : '#909399'

    const marker = L.circleMarker([lat, lng], {
      radius: 7,
      fillColor: color,
      color: '#fff',
      weight: 2,
      opacity: 1,
      fillOpacity: 0.85,
    }).addTo(mapInstance)

    marker.bindPopup(`
      <div style="min-width:160px">
        <b>${d.machine_id}</b><br>
        ${d.name}<br>
        <span style="color:#909399;font-size:12px">${d.address || ''}</span><br>
        <span style="color:${color};font-size:12px">● ${statusLabel(d.status)}</span>
        ${d.network_type ? ` <span style="color:#909399;font-size:12px">${d.network_type}</span>` : ''}
        <br><a href="/#/devices/${d.id}" style="font-size:12px">查看详情 →</a>
      </div>
    `)
    mapMarkers.push(marker)
  })
}

function onResize() {
  trendChart?.resize(); deviceChart?.resize(); rankChart?.resize()
  mapInstance?.invalidateSize()
}

onMounted(() => {
  load()
  window.addEventListener('resize', onResize)
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', onResize)
  trendChart?.dispose(); deviceChart?.dispose(); rankChart?.dispose()
})
</script>

<style lang="scss" scoped>
.dashboard { padding: 4px; }

.stat-card {
  background: #1a1f2c;
  border: 1px solid #2a3142;
  .stat-label {
    color: #909399;
    font-size: 13px;
    margin-bottom: 8px;
  }
  .stat-value {
    font-size: 28px;
    font-weight: 600;
  }
}

.chart-card {
  background: #1a1f2c;
  border: 1px solid #2a3142;
}

.chart {
  width: 100%;
  height: 280px;
}

.map-container {
  width: 100%;
  height: 400px;
  border-radius: 4px;
}

/* Phase 4.2 */
.stat-value-sm { font-size: 22px; font-weight: 600; }
.stat-value-sm .sep { margin: 0 6px; color: #555; font-weight: 400; }
.stat-sub { color: #909399; font-size: 12px; margin-top: 6px; }
.stat-sub .link { color: #409eff; text-decoration: none; }

.funnel-row {
  display: flex; align-items: center; gap: 8px;
  flex-wrap: wrap; padding: 6px 0;
}
.funnel-step {
  flex: 1;
  background: #0f1419;
  border: 1px solid #2a3142;
  border-radius: 8px;
  padding: 12px 10px;
  text-align: center;
  min-width: 80px;
}
.funnel-step-label { color: #909399; font-size: 12px; }
.funnel-step-value { font-size: 22px; font-weight: 600; color: #c0c4cc; margin-top: 4px; }
.funnel-step-rate { color: #67c23a; font-size: 11px; margin-top: 2px; }
.funnel-arrow { color: #555; font-size: 18px; flex-shrink: 0; }
.funnel-spacer { width: 18px; height: 1px; }
</style>
