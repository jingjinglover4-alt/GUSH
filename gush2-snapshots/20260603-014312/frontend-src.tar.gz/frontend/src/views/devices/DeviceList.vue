<template>
  <div class="device-list">
    <!-- 工具栏 -->
    <div class="toolbar">
      <el-input
        v-model="filters.search"
        placeholder="搜索 设备编号 / 名称 / 地址"
        clearable
        style="width: 280px"
        @keyup.enter="reload"
        @clear="reload"
      >
        <template #prefix><el-icon><Search /></el-icon></template>
      </el-input>

      <el-select v-model="filters.status" placeholder="全部状态" clearable style="width: 140px" @change="reload">
        <el-option label="在线" value="online" />
        <el-option label="离线" value="offline" />
        <el-option label="故障" value="fault" />
      </el-select>

      <el-button :icon="Refresh" @click="reload">刷新</el-button>

      <div class="spacer" />

      <el-button type="primary" :icon="Plus" @click="openCreate">新建设备</el-button>
    </div>

    <!-- 表格 -->
    <el-table
      v-loading="loading"
      :data="rows"
      stripe
      style="margin-top: 16px"
      @row-dblclick="(r) => goDetail(r.id)"
    >
      <el-table-column prop="machine_id" label="设备编号" width="130" />
      <el-table-column prop="name" label="名称" min-width="140" />
      <el-table-column label="状态" width="100">
        <template #default="{ row }">
          <el-tag :type="statusTag(row.status)" size="small">
            {{ statusLabel(row.status) }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="货道" width="120">
        <template #default="{ row }">
          {{ row.online_channels }} / {{ row.total_channels }}
        </template>
      </el-table-column>
      <el-table-column prop="address" label="安装地址" min-width="200" show-overflow-tooltip />
      <el-table-column prop="bound_project_name" label="绑定项目" width="160" show-overflow-tooltip />
      <el-table-column label="子域名" width="220">
        <template #default="{ row }">
          <el-link :href="row.public_url" target="_blank" type="primary">
            {{ row.subdomain }}.{{ sys.rootDomain }}
          </el-link>
        </template>
      </el-table-column>
      <el-table-column label="最后心跳" width="180">
        <template #default="{ row }">
          {{ row.last_heartbeat_at ? formatTime(row.last_heartbeat_at) : '—' }}
        </template>
      </el-table-column>
      <el-table-column label="操作" width="180" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click="goDetail(row.id)">详情</el-button>
          <el-button link type="warning" @click="openEdit(row)">编辑</el-button>
          <el-popconfirm title="确认删除该设备？" @confirm="remove(row)">
            <template #reference>
              <el-button link type="danger">删除</el-button>
            </template>
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>

    <!-- 新建 / 编辑 弹窗 -->
    <el-dialog v-model="dialogVisible" :title="editing ? '编辑设备' : '新建设备'" width="520px">
      <el-form ref="formRef" :model="form" :rules="rules" label-width="90px">
        <el-form-item label="设备名称" prop="name">
          <el-input v-model="form.name" maxlength="64" />
        </el-form-item>
        <el-form-item label="安装地址" prop="address">
          <el-input v-model="form.address" maxlength="200" />
        </el-form-item>
        <el-form-item label="绑定项目">
          <el-select v-model="form.bound_project" placeholder="请选择项目" clearable filterable style="width: 100%">
            <el-option
              v-for="p in projectOptions"
              :key="p.id"
              :label="p.name"
              :value="p.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="经度">
          <el-input v-model.number="form.longitude" placeholder="例如 104.065735" />
        </el-form-item>
        <el-form-item label="纬度">
          <el-input v-model.number="form.latitude" placeholder="例如 30.659462" />
        </el-form-item>
        <el-form-item v-if="!editing" label="自定义子域名">
          <el-input v-model="form.subdomain" placeholder="留空 = 自动 machineNNN.主域名">
            <template #append>.{{ sys.rootDomain }}</template>
          </el-input>
          <div class="hint">小写字母数字与连字符，3-32 字符；留空则系统按 machine_id 自动分配</div>
        </el-form-item>
        <el-alert
          v-if="!editing"
          type="info"
          :closable="false"
          show-icon
          style="margin-top: 4px"
        >
          创建后系统自动生成：设备编号、激活码、通信密钥，并初始化 60 个货道（A0–F9）。
        </el-alert>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="submit">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { reactive, ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Search, Refresh, Plus } from '@element-plus/icons-vue'
import { listMachines, createMachine, updateMachine, deleteMachine } from '@/api/devices'
import { listProjects } from '@/api/projects'
import { useSystemStore } from '@/stores/system'

const sys = useSystemStore()
const router = useRouter()

const loading = ref(false)
const rows = ref([])
const filters = reactive({ search: '', status: '' })
const projectOptions = ref([])

async function loadProjects() {
  try {
    const data = await listProjects()
    projectOptions.value = Array.isArray(data) ? data : (data.results || [])
  } catch (e) {
    projectOptions.value = []
  }
}

async function reload() {
  loading.value = true
  try {
    const data = await listMachines({
      search: filters.search || undefined,
      status: filters.status || undefined
    })
    // DRF 默认无分页 → 直接数组；有分页 → results
    rows.value = Array.isArray(data) ? data : (data.results || [])
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  loadProjects()
  reload()
})

function goDetail(id) {
  router.push(`/devices/${id}`)
}

function statusTag(s) {
  return ({ online: 'success', offline: 'info', fault: 'danger' })[s] || 'info'
}
function statusLabel(s) {
  return ({ online: '在线', offline: '离线', fault: '故障' })[s] || s
}
function formatTime(iso) {
  return new Date(iso).toLocaleString('zh-CN', { hour12: false })
}

// ---- 新建 / 编辑 ----
const dialogVisible = ref(false)
const editing = ref(null)
const saving = ref(false)
const formRef = ref()
const form = reactive({ name: '', address: '', longitude: null, latitude: null, subdomain: '', bound_project: null })
const rules = {
  name: [{ required: true, message: '请输入设备名称', trigger: 'blur' }]
}

function openCreate() {
  editing.value = null
  Object.assign(form, { name: '', address: '', longitude: null, latitude: null, bound_project: null })
  dialogVisible.value = true
}
function openEdit(row) {
  editing.value = row
  Object.assign(form, {
    name: row.name,
    address: row.address || '',
    longitude: row.longitude,
    latitude: row.latitude,
    bound_project: row.bound_project || null
  })
  dialogVisible.value = true
}

async function submit() {
  await formRef.value?.validate().catch(() => null)
  if (!form.name) return
  saving.value = true
  try {
    if (editing.value) {
      const { subdomain, ...rest } = form
      await updateMachine(editing.value.id, rest)
      ElMessage.success('保存成功')
    } else {
      await createMachine({ ...form })
      ElMessage.success('设备已创建，60 个货道已初始化')
    }
    dialogVisible.value = false
    await reload()
  } finally {
    saving.value = false
  }
}

async function remove(row) {
  await deleteMachine(row.id)
  ElMessage.success('已删除')
  await reload()
}
</script>

<style lang="scss" scoped>
.device-list {
  .toolbar {
    display: flex;
    align-items: center;
    gap: 12px;
    .spacer { flex: 1; }
  }
}
</style>
