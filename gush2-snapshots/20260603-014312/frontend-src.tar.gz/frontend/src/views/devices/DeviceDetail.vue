<template>
  <div v-loading="loading" class="device-detail">
    <!-- 顶部：基本信息 -->
    <el-card v-if="machine" shadow="never" class="info-card">
      <template #header>
        <div class="header-row">
          <el-button :icon="ArrowLeft" link @click="$router.push('/devices')">返回列表</el-button>
          <span class="title">{{ machine.machine_id }} · {{ machine.name }}</span>
          <el-tag :type="statusTag(machine.status)" size="small">{{ statusLabel(machine.status) }}</el-tag>
          <div class="spacer" />
          <el-button :icon="MagicStick" @click="openOverrideDialog">页面覆盖</el-button>
          <el-button :icon="Link" @click="openConsole">打开远程控制台</el-button>
          <el-button :icon="Refresh" @click="reload">刷新</el-button>
        </div>
      </template>

      <!-- Phase 5.1：访问地址 -->
      <div class="urls-block">
        <AccessUrlCard
          label="LED 大屏"
          :url="ledUrl"
          :machine-id="machine.id" />
        <AccessUrlCard
          label="LED 备用地址"
          :url="ledFallbackUrl"
          :machine-id="machine.id" />
        <AccessUrlCard
          v-if="machine.bound_project"
          label="H5 落地页"
          :url="h5BoundUrl"
          :machine-id="machine.id" />
      </div>

      <el-descriptions :column="3" border size="small">
        <el-descriptions-item label="子域名">
          <el-link :href="machine.public_url" target="_blank" type="primary">
            {{ machine.subdomain }}.{{ sys.rootDomain }}
          </el-link>
          <el-button :icon="EditPen" size="small" link type="primary"
                     @click="editSubdomainDlg = true" style="margin-left:8px">
            修改
          </el-button>
        </el-descriptions-item>
        <el-descriptions-item label="安装地址">{{ machine.address || '—' }}</el-descriptions-item>
        <el-descriptions-item label="经纬度">
          <template v-if="machine.longitude && machine.latitude">
            {{ machine.longitude }}, {{ machine.latitude }}
          </template>
          <span v-else style="color:var(--el-text-color-secondary)">未设置（填地址自动解析）</span>
        </el-descriptions-item>
        <el-descriptions-item label="绑定项目">{{ machine.bound_project_name || '—' }}</el-descriptions-item>
        <el-descriptions-item label="信号强度">{{ machine.signal_strength }}%</el-descriptions-item>
        <el-descriptions-item label="网络类型">{{ machine.network_type || '—' }}</el-descriptions-item>
        <el-descriptions-item label="固件版本">{{ machine.firmware_version || '—' }}</el-descriptions-item>
        <el-descriptions-item label="激活码">
          <code class="secret">{{ machine.activation_code }}</code>
        </el-descriptions-item>
        <el-descriptions-item label="通信密钥" :span="2">
          <code class="secret">{{ machine.comm_secret }}</code>
        </el-descriptions-item>
        <el-descriptions-item label="最后心跳">
          {{ machine.last_heartbeat_at ? formatTime(machine.last_heartbeat_at) : '—' }}
        </el-descriptions-item>
        <el-descriptions-item label="创建时间">{{ formatTime(machine.created_at) }}</el-descriptions-item>
        <el-descriptions-item label="运行时长">{{ formatRuntime(machine.runtime_seconds) }}</el-descriptions-item>
      </el-descriptions>
    </el-card>

    <!-- Phase 5.3：QT 注册信息 -->
    <el-card v-if="machine" shadow="never" class="info-card">
      <template #header>
        <div class="header-row">
          <span class="title">QT 注册信息</span>
          <span class="hint" style="margin-left:8px;color:#909399">提供给软硬件嵌入师，用于 Qt 设备端注册</span>
          <div class="spacer" />
          <el-button type="primary" size="small" plain @click="copyQtInfo">一键复制</el-button>
          <el-button type="success" size="small" plain @click="showQtQr = true">二维码</el-button>
        </div>
      </template>
      <div class="qt-info">
        <div class="qt-field">
          <span class="qt-label">设备编号</span>
          <code class="secret">{{ machine.machine_id }}</code>
        </div>
        <div class="qt-field">
          <span class="qt-label">通信域名</span>
          <code class="secret">{{ machine.subdomain }}.{{ sys.rootDomain }}</code>
        </div>
        <div class="qt-field" v-if="machine.network_plan">
          <span class="qt-label">网络制式</span>
          <el-tag size="small" :type="machine.network_plan === '4g' ? 'warning' : 'info'">
            {{ machine.network_plan === '4g' ? '4G' : 'WiFi' }}
          </el-tag>
          <span v-if="machine.network_plan === '4g' && machine.carrier" class="qt-hint">{{ machine.carrier }}</span>
        </div>
        <el-divider style="margin:8px 0;border-color:#2a3142" />
        <div class="qt-field">
          <span class="qt-label">控制台地址</span>
          <code class="secret url">{{ consoleUrl }}</code>
          <el-button :icon="CopyDocument" size="small" link type="primary" @click="copyText(consoleUrl)" />
        </div>
        <div class="qt-field">
          <span class="qt-label">WebSocket 地址</span>
          <code class="secret url">{{ wsUrl }}</code>
          <el-button :icon="CopyDocument" size="small" link type="primary" @click="copyText(wsUrl)" />
        </div>
        <el-divider style="margin:8px 0;border-color:#2a3142" />
        <div class="qt-field">
          <span class="qt-label">激活码</span>
          <code class="secret">{{ machine.activation_code }}</code>
          <el-button :icon="CopyDocument" size="small" link type="primary" @click="copyText(machine.activation_code)" />
        </div>
        <div class="qt-field">
          <span class="qt-label">通信密钥</span>
          <code class="secret">{{ machine.comm_secret }}</code>
          <el-button :icon="CopyDocument" size="small" link type="primary" @click="copyText(machine.comm_secret)" />
        </div>
      </div>
    </el-card>

    <!-- 二维码弹窗 -->
    <el-dialog v-model="showQtQr" title="QR 二维码 · Qt 控制台地址" width="380px" align-center>
      <div style="text-align:center">
        <el-image
          :src="qrImageUrl"
          fit="contain"
          style="width:280px;height:280px;background:#fff;border-radius:8px;padding:12px"
        />
        <p class="hint" style="margin-top:12px;text-align:center">设备端 Qt WebView 扫此码加载控制台</p>
      </div>
    </el-dialog>

    <!-- Phase 5.2：网络方案 -->
    <el-card v-if="machine" shadow="never" class="info-card">
      <template #header>
        <div class="header-row">
          <span class="title">网络方案</span>
          <span v-if="machine.network_plan" class="hint" style="margin-left:8px">
            <el-tag size="small" :type="machine.network_plan === '4g' ? 'warning' : 'info'">
              {{ machine.network_plan === '4g' ? '4G' : 'WiFi' }}
            </el-tag>
          </span>
          <span v-else class="hint" style="margin-left:8px;color:#909399">未配置</span>
          <div class="spacer" />
          <el-button :icon="EditPen" size="small" plain @click="openNetworkPlan()">编辑</el-button>
        </div>
      </template>
      <el-descriptions v-if="machine.network_plan" :column="3" border size="small">
        <el-descriptions-item label="Wi-Fi名称">{{ machine.wifi_ssid || '—' }}</el-descriptions-item>
        <el-descriptions-item label="Wi-Fi密码">
          <code class="secret" style="font-size:11px">{{ machine.wifi_password || '—' }}</code>
        </el-descriptions-item>
        <el-descriptions-item label="登陆IP">{{ machine.wifi_login_ip || '—' }}</el-descriptions-item>
        <el-descriptions-item label="Wi-Fi登陆用户名">{{ machine.wifi_login_username || '—' }}</el-descriptions-item>
        <el-descriptions-item label="Wi-Fi登陆密码">
          <code class="secret" style="font-size:11px">{{ machine.wifi_login_password || '—' }}</code>
        </el-descriptions-item>
        <template v-if="machine.network_plan === '4g'">
        <el-descriptions-item label="运营商">{{ machine.carrier || '—' }}</el-descriptions-item>
        <el-descriptions-item label="SIM卡号/SN">
          <code class="secret" style="font-size:11px">{{ machine.iccid || '—' }}</code>
        </el-descriptions-item>
        <el-descriptions-item label="套餐月费">{{ machine.plan_fee ? '¥' + machine.plan_fee + '/月' : '—' }}</el-descriptions-item>
        <el-descriptions-item label="月流量">
          <div v-if="machine.data_limit_mb">
            <span>{{ formatDataUsage(machine.data_used_mb) }} / {{ formatDataUsage(machine.data_limit_mb) }}</span>
            <el-progress
              :percentage="Math.min(100, Math.round((machine.data_used_mb || 0) / machine.data_limit_mb * 100))"
              :status="dataUsageStatus(machine.data_used_mb, machine.data_limit_mb)"
              :stroke-width="12"
              style="margin-top:4px;width:200px"
            />
          </div>
          <span v-else>—</span>
        </el-descriptions-item>
        <el-descriptions-item label="套餐生效日">{{ machine.plan_start_date || '—' }}</el-descriptions-item>
        <el-descriptions-item label="续费日期">
          <span v-if="machine.renewal_date">
            {{ machine.renewal_date }}
            <el-tag v-if="renewalDaysLeft(machine.renewal_date) <= 7"
                    :type="renewalDaysLeft(machine.renewal_date) <= 0 ? 'danger' : 'warning'"
                    size="small" style="margin-left:6px">
              {{ renewalDaysLeft(machine.renewal_date) <= 0 ? '已到期' : `剩${renewalDaysLeft(machine.renewal_date)}天` }}
            </el-tag>
          </span>
          <span v-else>—</span>
        </el-descriptions-item>
        </template>
      </el-descriptions>
      <div v-else class="unset-row">尚未配置网络方案</div>
    </el-card>

    <!-- 编辑网络方案 -->
    <el-dialog v-model="networkPlanDlg" title="编辑网络方案" width="540px">
      <el-form label-width="120px" label-position="left">
        <el-form-item label="网络制式">
          <el-radio-group v-model="netForm.network_plan">
            <el-radio value="">未配置</el-radio>
            <el-radio value="wifi">WiFi</el-radio>
            <el-radio value="4g">4G</el-radio>
          </el-radio-group>
        </el-form-item>
        <template v-if="netForm.network_plan === '4g'">
          <el-form-item label="运营商">
            <el-select v-model="netForm.carrier" placeholder="选择运营商" style="width:100%">
              <el-option value="中国移动" label="中国移动" />
              <el-option value="中国联通" label="中国联通" />
              <el-option value="中国电信" label="中国电信" />
            </el-select>
          </el-form-item>
          <el-form-item label="SIM卡号/SN">
            <el-input v-model="netForm.iccid" placeholder="SIM卡号或SN" maxlength="32" />
          </el-form-item>
          <el-form-item label="月流量上限">
            <el-select v-model="netForm.data_limit_mb" placeholder="选择流量" style="width:100%">
              <el-option :value="1024" label="1 GB" />
              <el-option :value="3072" label="3 GB" />
              <el-option :value="5120" label="5 GB" />
              <el-option :value="10240" label="10 GB" />
              <el-option :value="30720" label="30 GB" />
              <el-option :value="51200" label="50 GB" />
              <el-option :value="102400" label="100 GB" />
              <el-option :label="'自定义'" disabled />
            </el-select>
          </el-form-item>
          <el-form-item label="当月已用流量">
            <el-input-number v-model="netForm.data_used_mb" :min="0" :max="netForm.data_limit_mb || 0" />
            <span class="hint">MB</span>
          </el-form-item>
          <el-form-item label="套餐月费">
            <el-input-number v-model="netForm.plan_fee" :min="0" :precision="2" :step="10" />
            <span class="hint">元</span>
          </el-form-item>
          <el-form-item label="套餐生效日">
            <el-date-picker v-model="netForm.plan_start_date" type="date" value-format="YYYY-MM-DD" style="width:100%" />
          </el-form-item>
          <el-form-item label="续费日期">
            <el-date-picker v-model="netForm.renewal_date" type="date" value-format="YYYY-MM-DD" style="width:100%" />
          </el-form-item>
        </template>
        <template v-if="netForm.network_plan === 'wifi' || netForm.network_plan === '4g'">
          <el-divider content-position="left">Wi-Fi 凭据（4G mini Wi-Fi 也需填写）</el-divider>
          <el-form-item label="Wi-Fi名称">
            <el-input v-model="netForm.wifi_ssid" placeholder="输入 Wi-Fi SSID" maxlength="64" />
          </el-form-item>
          <el-form-item label="Wi-Fi密码">
            <el-input v-model="netForm.wifi_password" placeholder="输入 Wi-Fi 密码" maxlength="128" show-password />
          </el-form-item>
          <el-form-item label="登陆IP">
            <el-input v-model="netForm.wifi_login_ip" placeholder="如 192.168.1.1" maxlength="64" />
          </el-form-item>
          <el-form-item label="Wi-Fi登陆用户名">
            <el-input v-model="netForm.wifi_login_username" placeholder="路由器管理账号" maxlength="64" />
          </el-form-item>
          <el-form-item label="Wi-Fi登陆密码">
            <el-input v-model="netForm.wifi_login_password" placeholder="路由器管理密码" maxlength="128" show-password />
          </el-form-item>
        </template>
      </el-form>
      <template #footer>
        <el-button @click="networkPlanDlg = false">取消</el-button>
        <el-button type="primary" :loading="savingNetPlan" @click="saveNetworkPlan">保存</el-button>
      </template>
    </el-dialog>

    <!-- 货道矩阵 -->
    <el-card v-if="machine" shadow="never" class="matrix-card">
      <template #header>
        <div class="header-row">
          <span class="title">货道矩阵（6 层 × 10 列 = 60 个货道）</span>
          <div class="legend">
            <span class="dot normal" /> 正常
            <span class="dot low" /> 库存低
            <span class="dot empty" /> 缺货
            <span class="dot fault" /> 故障
          </div>
          <span class="spacer" />
          <el-button
            type="success" size="small" plain
            :loading="bulkLoading"
            @click="doRefill"
          >
            一键补满（已绑货道）
          </el-button>
          <el-button
            type="primary" size="small" plain
            @click="openBulkAssign"
          >
            批量投放礼品到空货道
          </el-button>
        </div>
      </template>

      <div class="matrix">
        <!-- 列头 0-9 -->
        <div class="row header">
          <div class="row-label" />
          <div v-for="c in 10" :key="c" class="col-head">{{ c - 1 }}</div>
        </div>
        <div v-for="row in rows" :key="row" class="row">
          <div class="row-label">{{ row }}</div>
          <div
            v-for="ch in channelsOfRow(row)"
            :key="ch.id"
            class="cell"
            :class="ch.status"
            @click="openChannel(ch)"
          >
            <div class="cell-code">{{ ch.channel_code }}</div>
            <div class="cell-stock">{{ ch.current_stock }}/{{ ch.capacity }}</div>
          </div>
        </div>
      </div>
    </el-card>

    <!-- 货道操作弹窗 -->
    <el-dialog
      v-model="channelDialog"
      :title="`货道 ${currentChannel?.channel_code || ''} 操作`"
      width="460px"
    >
      <template v-if="currentChannel">
        <el-descriptions :column="2" border size="small">
          <el-descriptions-item label="货道">{{ currentChannel.channel_code }}</el-descriptions-item>
          <el-descriptions-item label="层号">第 {{ currentChannel.layer }} 层</el-descriptions-item>
          <el-descriptions-item label="状态">
            <el-tag size="small" :type="channelTag(currentChannel.status)">
              {{ channelLabel(currentChannel.status) }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="库存">
            {{ currentChannel.current_stock }} / {{ currentChannel.capacity }}
          </el-descriptions-item>
          <el-descriptions-item label="绑定商品" :span="2">
            {{ currentChannel.product_name || '未绑定' }}
          </el-descriptions-item>
          <el-descriptions-item v-if="currentChannel.fault_message" label="故障信息" :span="2">
            {{ currentChannel.fault_message }}
          </el-descriptions-item>
        </el-descriptions>

        <el-tabs v-model="activeAction" style="margin-top: 16px">
          <el-tab-pane label="补货" name="restock">
            <el-form label-width="100px">
              <el-form-item label="选择礼品">
                <el-select
                  v-model="restockProductId"
                  filterable
                  placeholder="从仓库有货的礼品中选择"
                  style="width: 100%"
                  @visible-change="(v) => v && loadStockProducts()"
                >
                  <el-option
                    v-for="p in stockProducts"
                    :key="p.id"
                    :value="p.id"
                    :label="`${p.sku} · ${p.name}（仓库 ${p.total_stock}）`"
                    :disabled="p.total_stock <= 0"
                  />
                </el-select>
                <div v-if="currentChannel.product_name" class="hint" style="margin-left:0">
                  当前已绑定：<b>{{ currentChannel.product_name }}</b>
                </div>
              </el-form-item>
              <el-form-item label="补货数量">
                <el-input-number
                  v-model="restockQty"
                  :min="1"
                  :max="Math.max(1, currentChannel.capacity - currentChannel.current_stock)"
                />
                <span class="hint">货道剩余空位 {{ currentChannel.capacity - currentChannel.current_stock }}</span>
              </el-form-item>
            </el-form>
            <el-button
              type="primary"
              :loading="acting"
              :disabled="currentChannel.current_stock >= currentChannel.capacity || !restockProductId"
              @click="doRestock"
            >
              确认补货（仓库出库 → 装车）
            </el-button>
          </el-tab-pane>

          <el-tab-pane label="回库" name="return">
            <el-alert
              type="info"
              :closable="false"
              show-icon
              style="margin-bottom: 12px"
            >
              把货道里剩余库存收回到仓库（活动下架 / 换品前必做）。
              回库后若货道为空，会自动解绑礼品。
            </el-alert>
            <el-form label-width="100px">
              <el-form-item label="当前货道">
                <el-tag size="small">
                  {{ currentChannel.product_name || '未绑定' }}
                </el-tag>
                <span class="hint">货道库存 {{ currentChannel.current_stock }}</span>
              </el-form-item>
              <el-form-item label="回库数量">
                <el-input-number
                  v-model="returnQty"
                  :min="1"
                  :max="Math.max(1, currentChannel.current_stock)"
                  :disabled="currentChannel.current_stock <= 0"
                />
                <span class="hint">最多 {{ currentChannel.current_stock }} 件</span>
              </el-form-item>
              <el-form-item label="备注">
                <el-input v-model="returnNote" maxlength="120" placeholder="例如：项目结束下架" />
              </el-form-item>
            </el-form>
            <el-button
              type="warning"
              :loading="acting"
              :disabled="currentChannel.current_stock <= 0 || !currentChannel.product"
              @click="doReturn"
            >
              确认回库（货道 → 仓库）
            </el-button>
          </el-tab-pane>

          <el-tab-pane label="后台测试出货" name="dispense">
            <el-alert
              type="info"
              :closable="false"
              show-icon
              style="margin-bottom: 12px"
            >
              仅修改数据库（库存 -1 + 写 DispenseLog），不通过 WebSocket 下发硬件。
            </el-alert>
            <el-button
              type="warning"
              :loading="acting"
              :disabled="currentChannel.current_stock <= 0 || currentChannel.status === 'fault'"
              @click="doDispense"
            >
              后台测试出货 1 次
            </el-button>
          </el-tab-pane>

          <el-tab-pane label="远程下发出货" name="remote">
            <el-alert
              :type="machine.status === 'online' ? 'success' : 'warning'"
              :closable="false"
              show-icon
              style="margin-bottom: 12px"
            >
              <template v-if="machine.status === 'online'">
                设备在线，将通过 WebSocket 下发 <code>motor_run</code> 指令到 STM32。
              </template>
              <template v-else>
                设备当前离线（无远程控制台连接），下发后会进入消息队列，但不会被执行。
              </template>
            </el-alert>
            <el-form label-width="80px">
              <el-form-item label="次数">
                <el-input-number v-model="remoteNum" :min="1" :max="5" />
              </el-form-item>
            </el-form>
            <el-button
              type="primary"
              :loading="acting"
              :disabled="currentChannel.status === 'fault'"
              @click="doRemoteDispense"
            >
              下发 motor_run {{ currentChannel.channel_code }}
            </el-button>
          </el-tab-pane>

          <el-tab-pane label="故障" name="fault">
            <el-form label-width="80px">
              <el-form-item v-if="currentChannel.status !== 'fault'" label="故障描述">
                <el-input v-model="faultMessage" placeholder="例如：电机卡死" maxlength="200" />
              </el-form-item>
            </el-form>
            <el-button
              v-if="currentChannel.status !== 'fault'"
              type="danger"
              :loading="acting"
              @click="doMarkFault(true)"
            >
              标记为故障
            </el-button>
            <el-button
              v-else
              type="success"
              :loading="acting"
              @click="doMarkFault(false)"
            >
              清除故障
            </el-button>
          </el-tab-pane>
        </el-tabs>
      </template>
    </el-dialog>

    <!-- 批量投放礼品到空货道 -->
    <el-dialog v-model="bulkAssignDialog" title="批量投放礼品到空货道" width="640px">
      <el-form label-width="100px">
        <el-form-item label="选择礼品">
          <el-select
            v-model="bulkAssignProductId"
            filterable
            placeholder="从仓库有货的礼品中选择"
            style="width: 100%"
            @visible-change="(v) => v && loadStockProducts()"
          >
            <el-option
              v-for="p in stockProducts"
              :key="p.id"
              :value="p.id"
              :label="`${p.sku} · ${p.name}（仓库 ${p.total_stock}）`"
              :disabled="p.total_stock <= 0"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="目标货道">
          <div class="bulk-channel-toolbar">
            <el-button size="small" link @click="selectAllEmptyUnbound">
              选中所有「空 + 未绑定」({{ emptyUnboundChannels.length }})
            </el-button>
            <el-button size="small" link @click="bulkAssignChannelIds = []">清空</el-button>
            <span class="hint" style="margin-left: auto">已选 {{ bulkAssignChannelIds.length }} 个</span>
          </div>
          <div class="channel-grid">
            <el-checkbox-group v-model="bulkAssignChannelIds">
              <el-checkbox
                v-for="ch in selectableChannels"
                :key="ch.id"
                :label="ch.id"
                :value="ch.id"
                :disabled="ch.status === 'fault' || ch.current_stock >= ch.capacity"
              >
                {{ ch.channel_code }}
                <span class="muted">({{ ch.current_stock }}/{{ ch.capacity }})</span>
              </el-checkbox>
            </el-checkbox-group>
          </div>
          <div class="hint">
            已被其他礼品占用且有库存的货道（不可装新礼品）已隐藏；故障/已满会自动跳过
          </div>
        </el-form-item>

        <el-form-item label="备注">
          <el-input v-model="bulkAssignNote" maxlength="120" placeholder="例如：5月20日新上架" />
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button @click="bulkAssignDialog = false">取消</el-button>
        <el-button
          type="primary"
          :loading="bulkLoading"
          :disabled="!bulkAssignProductId || bulkAssignChannelIds.length === 0"
          @click="doBulkAssign"
        >
          确认投放（{{ bulkAssignChannelIds.length }} 个货道）
        </el-button>
      </template>
    </el-dialog>

    <!-- 批量操作结果 -->
    <el-dialog v-model="bulkResultDialog" title="批量操作结果" width="720px">
      <template v-if="bulkResult">
        <div class="bulk-summary">
          <el-tag type="success" size="large">补满 {{ bulkResult.summary.filled }}</el-tag>
          <el-tag type="warning" size="large">部分补 {{ bulkResult.summary.partial }}</el-tag>
          <el-tag type="info" size="large">跳过 {{ bulkResult.summary.skipped }}</el-tag>
          <el-tag effect="dark" size="large">共补 {{ bulkResult.summary.total_qty }} 件</el-tag>
        </div>

        <h4>仓库扣减</h4>
        <el-table :data="bulkResult.warehouse_changes" size="small" border>
          <el-table-column label="SKU" prop="sku" width="120" />
          <el-table-column label="礼品" prop="name" />
          <el-table-column label="扣减数量" prop="deducted" width="100" align="center" />
          <el-table-column label="仓库剩余" prop="warehouse_after" width="100" align="center" />
        </el-table>

        <h4>明细</h4>
        <el-table :data="bulkResult.details" size="small" border max-height="320">
          <el-table-column label="货道" prop="channel_code" width="80" />
          <el-table-column label="状态" width="100">
            <template #default="{ row }">
              <el-tag size="small" :type="bulkStatusTag(row.status)">
                {{ bulkStatusLabel(row.status) }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column label="补入" prop="qty" width="70" align="center" />
          <el-table-column label="货道库存" prop="channel_stock_after" width="100" align="center" />
          <el-table-column label="说明">
            <template #default="{ row }">
              <span class="muted">{{ bulkReasonLabel(row.reason) || '—' }}</span>
            </template>
          </el-table-column>
        </el-table>
      </template>
      <template #footer>
        <el-button type="primary" @click="bulkResultDialog = false">关闭</el-button>
      </template>
    </el-dialog>

    <!-- ===== 设备级页面覆盖 dialog (Phase 1.7) ===== -->
    <el-dialog v-model="overrideDialog" :title="`页面覆盖 · ${machine?.machine_id || ''}`" width="640px" destroy-on-close>
      <el-alert :closable="false" type="info" style="margin-bottom:14px">
        覆盖仅影响这一台设备。留空 → 用项目级默认。
        设置后会立即生效于 <b>/led/{{ machine?.machine_id }}/</b> 与 <b>{{ machine?.subdomain }}.{{ sys.rootDomain }}</b>。
      </el-alert>

      <el-form label-width="120px" label-position="left">
        <el-form-item label="启用覆盖">
          <el-switch v-model="overrideForm.enabled" />
          <span class="hint" style="margin-left:8px">关闭后将完全回落到项目级配置</span>
        </el-form-item>

        <el-divider>多项目分发</el-divider>
        <el-form-item label="活跃项目">
          <el-select v-model="overrideForm.active_project" placeholder="留空 = 默认（最新 running 项目）"
                     clearable style="width:100%">
            <el-option
              v-for="p in overrideData?.bound_projects || []"
              :key="p.id"
              :label="`${p.name}（${projStatusLabel(p.status)}）`"
              :value="p.id" />
          </el-select>
          <div class="hint">
            一台设备绑多个 running 项目时，必须显式指定此处。LED 与子域名落地页都会按此项目渲染。
          </div>
        </el-form-item>

        <el-divider>主题覆盖（只填要改的）</el-divider>
        <el-form-item label="品牌主色">
          <el-color-picker v-model="overrideForm.theme_override.brand_color" color-format="hex" />
          <el-button v-if="overrideForm.theme_override.brand_color" link type="primary"
                     @click="overrideForm.theme_override.brand_color = ''">清除</el-button>
        </el-form-item>

        <el-divider>LED 覆盖</el-divider>
        <el-form-item label="LED 标题">
          <el-input v-model="overrideForm.led_override.header_title" placeholder="留空 → 用项目级" clearable />
        </el-form-item>
        <el-form-item label="底部提示">
          <el-input v-model="overrideForm.led_override.footer_tip" placeholder="留空 → 用项目级" clearable />
        </el-form-item>
        <el-form-item label="二维码（本机）">
          <el-upload
            :show-file-list="false"
            :http-request="uploadOverrideQr"
            accept="image/*">
            <el-button :icon="Picture" size="small">上传该设备专属二维码</el-button>
          </el-upload>
          <el-image v-if="overrideData?.led_qr_image_url"
                    :src="overrideData.led_qr_image_url"
                    style="width:64px;height:64px;margin-left:12px;background:#fff;border-radius:6px;padding:4px" />
        </el-form-item>

        <el-divider>H5 覆盖</el-divider>
        <el-form-item label="H5 标题">
          <el-input v-model="overrideForm.h5_override.header_title" placeholder="留空 → 用项目级" clearable />
        </el-form-item>
        <el-form-item label="H5 副标题">
          <el-input v-model="overrideForm.h5_override.header_subtitle" placeholder="留空 → 用项目级" clearable />
        </el-form-item>

        <el-form-item label="备注">
          <el-input v-model="overrideForm.note" placeholder="例：旗舰店专用、活动日特供" maxlength="255" />
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button :loading="overrideSaving" type="danger" plain @click="clearOverride">清除全部覆盖</el-button>
        <div style="flex:1" />
        <el-button @click="overrideDialog = false">取消</el-button>
        <el-button type="primary" :loading="overrideSaving" @click="saveOverride">保存覆盖</el-button>
      </template>
    </el-dialog>

    <!-- Phase 5.1 修改子域名 -->
    <el-dialog v-model="editSubdomainDlg" title="修改子域名" width="460px">
      <el-form label-width="100px" label-position="left">
        <el-form-item label="新子域名">
          <el-input v-model="newSubdomain" placeholder="如 feidou-shop1">
            <template #append>.{{ sys.rootDomain }}</template>
          </el-input>
        </el-form-item>
        <el-alert type="info" :closable="false">
          只能用小写字母、数字、连字符；长度 3-32。改后旧地址立即失效，请同步更新打印的二维码。
        </el-alert>
      </el-form>
      <template #footer>
        <el-button @click="editSubdomainDlg = false">取消</el-button>
        <el-button type="primary" :loading="savingSubdomain" @click="saveSubdomain">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { ArrowLeft, Refresh, Link, MagicStick, Picture, EditPen, CopyDocument } from '@element-plus/icons-vue'
import AccessUrlCard from '@/components/AccessUrlCard.vue'
import { useSystemStore } from '@/stores/system'
import { ElMessageBox } from 'element-plus'
import {
  getMachine,
  restockChannel,
  dispenseChannel,
  setChannelFault,
  sendCommand,
  bulkRestockMachine,
  updateMachine,
} from '@/api/devices'
import { listProducts } from '@/api/products'
import { returnChannelToWarehouse } from '@/api/stock'
import { getDeviceOverride, updateDeviceOverride, clearDeviceOverride } from '@/api/pages'

const route = useRoute()
const id = route.params.id

const loading = ref(false)
const machine = ref(null)
const rows = ['A', 'B', 'C', 'D', 'E', 'F']

async function reload() {
  loading.value = true
  try {
    machine.value = await getMachine(id)
  } finally {
    loading.value = false
  }
}
onMounted(reload)

// ============ Phase 5.3：QT 注册信息 ============
const showQtQr = ref(false)

const consoleUrl = computed(() => {
  if (!machine.value) return ''
  const m = machine.value
  return `https://${m.subdomain}.${sys.rootDomain}/console/?machine_id=${encodeURIComponent(m.machine_id)}&secret=${encodeURIComponent(m.comm_secret)}`
})

const wsUrl = computed(() => {
  if (!machine.value) return ''
  const m = machine.value
  return `wss://${m.subdomain}.${sys.rootDomain}/ws/device/?machine_id=${encodeURIComponent(m.machine_id)}&secret=${encodeURIComponent(m.comm_secret)}`
})

const qrImageUrl = computed(() => {
  if (!machine.value) return ''
  return `/api/devices/machines/${machine.value.id}/qrcode/?url=${encodeURIComponent(consoleUrl.value)}&size=512`
})

const qtInfoText = computed(() => {
  if (!machine.value) return ''
  const m = machine.value
  const netPlan = m.network_plan === '4g' ? '4G' : m.network_plan === 'wifi' ? 'WiFi' : '未配置'
  const carrier = m.network_plan === '4g' && m.carrier ? `（${m.carrier}）` : ''
  return [
    `━━━ QT 注册信息 ━━━━━━━━━━━━━━━━━━━━`,
    `设备编号:    ${m.machine_id}`,
    `通信域名:    ${m.subdomain}.${sys.rootDomain}`,
    `网络制式:    ${netPlan}${carrier}`,
    `────────────────────────────────────`,
    `控制台地址:`,
    consoleUrl.value,
    ``,
    `WebSocket 地址:`,
    wsUrl.value,
    ``,
    `激活码:     ${m.activation_code}`,
    `通信密钥:   ${m.comm_secret}`,
    `────────────────────────────────────`,
    `请将此信息提供给嵌入工程师用于 STM32 + Qt 设备注册。`,
  ].join('\n')
})

function copyText(text) {
  navigator.clipboard.writeText(text).then(() => {
    ElMessage.success('已复制到剪贴板')
  }).catch(() => {
    // fallback
    const ta = document.createElement('textarea')
    ta.value = text
    ta.style.position = 'fixed'
    ta.style.left = '-9999px'
    document.body.appendChild(ta)
    ta.select()
    document.execCommand('copy')
    document.body.removeChild(ta)
    ElMessage.success('已复制到剪贴板')
  })
}

async function copyQtInfo() {
  try {
    await navigator.clipboard.writeText(qtInfoText.value)
    ElMessage.success('QT 注册信息已复制，可粘贴发送给嵌入师')
  } catch {
    copyText(qtInfoText.value)
    ElMessage.success('QT 注册信息已复制，可粘贴发送给嵌入师')
  }
}

// ============ Phase 5.2：网络方案 ============
const networkPlanDlg = ref(false)
const savingNetPlan = ref(false)
const netForm = ref({
  network_plan: '',
  wifi_ssid: '',
  wifi_password: '',
  wifi_login_ip: '',
  wifi_login_username: '',
  wifi_login_password: '',
  carrier: '',
  iccid: '',
  data_limit_mb: null,
  data_used_mb: 0,
  plan_fee: null,
  plan_start_date: null,
  renewal_date: null,
})

function openNetworkPlan() {
  const m = machine.value || {}
  netForm.value = {
    network_plan: m.network_plan || '',
    wifi_ssid: m.wifi_ssid || '',
    wifi_password: m.wifi_password || '',
    wifi_login_ip: m.wifi_login_ip || '',
    wifi_login_username: m.wifi_login_username || '',
    wifi_login_password: m.wifi_login_password || '',
    carrier: m.carrier || '',
    iccid: m.iccid || '',
    data_limit_mb: m.data_limit_mb || null,
    data_used_mb: m.data_used_mb || 0,
    plan_fee: m.plan_fee || null,
    plan_start_date: m.plan_start_date || null,
    renewal_date: m.renewal_date || null,
  }
  networkPlanDlg.value = true
}

async function saveNetworkPlan() {
  savingNetPlan.value = true
  try {
    const payload = { ...netForm.value }
    if (payload.network_plan === 'wifi') {
      // WiFi → 清空 4G 字段（Wi-Fi 凭据保留）
      payload.carrier = ''
      payload.iccid = ''
      payload.data_limit_mb = null
      payload.data_used_mb = null
      payload.plan_fee = null
      payload.plan_start_date = null
      payload.renewal_date = null
    } else if (payload.network_plan === '4g') {
      // 4G → 保留 Wi-Fi 凭据（4G mini Wi-Fi 也需要）
      // 只清除 4G 无关字段
    } else {
      // 未配置 → 清空所有
      payload.carrier = ''
      payload.iccid = ''
      payload.data_limit_mb = null
      payload.data_used_mb = null
      payload.plan_fee = null
      payload.plan_start_date = null
      payload.renewal_date = null
      payload.wifi_ssid = ''
      payload.wifi_password = ''
      payload.wifi_login_ip = ''
      payload.wifi_login_username = ''
      payload.wifi_login_password = ''
    }
    const updated = await updateMachine(id, payload)
    machine.value = updated
    ElMessage.success('网络方案已保存')
    networkPlanDlg.value = false
  } finally {
    savingNetPlan.value = false
  }
}

function formatDataUsage(mb) {
  if (!mb && mb !== 0) return '—'
  if (mb >= 1024) return (mb / 1024).toFixed(1) + ' GB'
  return mb + ' MB'
}

function dataUsageStatus(used, limit) {
  if (!used || !limit) return ''
  const pct = used / limit
  if (pct >= 0.9) return 'exception'
  if (pct >= 0.7) return 'warning'
  return 'success'
}

function renewalDaysLeft(dateStr) {
  if (!dateStr) return 999
  const now = new Date()
  const d = new Date(dateStr)
  return Math.ceil((d - now) / (1000 * 60 * 60 * 24))
}

// ============ Phase 5.1：访问地址 ============
const sys = useSystemStore()
const ledUrl = computed(() => machine.value ? sys.ledUrl(machine.value.subdomain) : '')
const ledFallbackUrl = computed(() => machine.value ? sys.ledFallbackUrl(machine.value.machine_id) : '')
const h5BoundUrl = computed(() => {
  if (!machine.value || !machine.value.bound_project) return ''
  return sys.h5Url(machine.value.bound_project, machine.value.machine_id)
})

// 修改子域名
const editSubdomainDlg = ref(false)
const newSubdomain = ref('')
const savingSubdomain = ref(false)

async function saveSubdomain() {
  if (!newSubdomain.value) {
    ElMessage.warning('请输入子域名')
    return
  }
  savingSubdomain.value = true
  try {
    const updated = await updateMachine(id, { subdomain: newSubdomain.value.trim() })
    machine.value = updated
    ElMessage.success('子域名已更新')
    editSubdomainDlg.value = false
    newSubdomain.value = ''
  } finally {
    savingSubdomain.value = false
  }
}

// ============ Phase 1.7：设备级页面覆盖 ============
const overrideDialog = ref(false)
const overrideSaving = ref(false)
const overrideData = ref(null)
const overrideForm = ref({
  enabled: true,
  note: '',
  active_project: null,
  theme_override: { brand_color: '' },
  h5_override: { header_title: '', header_subtitle: '' },
  led_override: { header_title: '', footer_tip: '' }
})

function projStatusLabel(s) {
  return ({ draft: '草稿', running: '进行中', paused: '已暂停', finished: '已结束' })[s] || s
}

function syncOverrideForm(d) {
  overrideData.value = d
  overrideForm.value = {
    enabled: !!d.enabled,
    note: d.note || '',
    active_project: d.active_project || null,
    theme_override: {
      brand_color: d.theme_override?.brand_color || ''
    },
    h5_override: {
      header_title: d.h5_override?.header_title || '',
      header_subtitle: d.h5_override?.header_subtitle || ''
    },
    led_override: {
      header_title: d.led_override?.header_title || '',
      footer_tip: d.led_override?.footer_tip || ''
    }
  }
}

async function openOverrideDialog() {
  try {
    const data = await getDeviceOverride(machine.value.machine_id)
    syncOverrideForm(data)
    overrideDialog.value = true
  } catch (e) { /* http 拦截器已弹错 */ }
}

// 把表单组装回 sparse JSON（空字符串字段不发送）
function pruneEmpty(obj) {
  const out = {}
  for (const [k, v] of Object.entries(obj)) {
    if (v !== '' && v !== null && v !== undefined) out[k] = v
  }
  return out
}

async function saveOverride() {
  overrideSaving.value = true
  try {
    const payload = {
      enabled: overrideForm.value.enabled,
      note: overrideForm.value.note,
      active_project: overrideForm.value.active_project || null,
      theme_override: pruneEmpty(overrideForm.value.theme_override),
      h5_override: pruneEmpty(overrideForm.value.h5_override),
      led_override: pruneEmpty(overrideForm.value.led_override)
    }
    const updated = await updateDeviceOverride(machine.value.machine_id, payload)
    syncOverrideForm({ ...updated, exists: true })
    ElMessage.success('已保存覆盖（立即生效）')
    overrideDialog.value = false
  } finally {
    overrideSaving.value = false
  }
}

async function clearOverride() {
  try {
    await ElMessageBox.confirm(
      '将清除该设备的所有页面覆盖，回落到项目级配置。确认？',
      '清除覆盖', { type: 'warning' }
    )
    overrideSaving.value = true
    await clearDeviceOverride(machine.value.machine_id)
    ElMessage.success('已清除覆盖')
    overrideDialog.value = false
  } catch (e) {
    if (e !== 'cancel') throw e
  } finally {
    overrideSaving.value = false
  }
}

async function uploadOverrideQr(opt) {
  const fd = new FormData()
  fd.append('led_qr_image', opt.file)
  try {
    const updated = await updateDeviceOverride(machine.value.machine_id, fd)
    syncOverrideForm({ ...updated, exists: true })
    ElMessage.success('二维码已上传')
  } catch (e) {
    opt.onError?.(e)
  }
}

function channelsOfRow(rowLetter) {
  const all = machine.value?.channels || []
  return all
    .filter((c) => c.row === rowLetter)
    .sort((a, b) => a.col - b.col)
}

// ----- 货道操作 -----
const channelDialog = ref(false)
const currentChannel = ref(null)
const activeAction = ref('restock')
const acting = ref(false)
const restockQty = ref(1)
const restockProductId = ref(null)
const stockProducts = ref([])
const faultMessage = ref('')
const remoteNum = ref(1)
const returnQty = ref(1)
const returnNote = ref('')

// ----- 批量补货 -----
const bulkLoading = ref(false)
const bulkAssignDialog = ref(false)
const bulkAssignProductId = ref(null)
const bulkAssignChannelIds = ref([])
const bulkAssignNote = ref('')
const bulkResultDialog = ref(false)
const bulkResult = ref(null)

const emptyUnboundChannels = computed(() => {
  return (machine.value?.channels || []).filter(
    c => !c.product && c.current_stock === 0 && c.status !== 'fault'
  )
})
// 可被「批量投放」勾选的货道：未被其他礼品占用且有库存的
const selectableChannels = computed(() => {
  const pid = bulkAssignProductId.value
  return (machine.value?.channels || [])
    .filter(c => {
      if (c.status === 'fault') return false
      if (c.current_stock >= c.capacity) return false
      // 已绑定其他礼品且有库存 → 不能装新礼品（隐藏）
      if (pid && c.product && c.product !== pid && c.current_stock > 0) return false
      return true
    })
    .sort((a, b) => a.channel_code.localeCompare(b.channel_code))
})

function selectAllEmptyUnbound() {
  bulkAssignChannelIds.value = emptyUnboundChannels.value.map(c => c.id)
}

function openBulkAssign() {
  bulkAssignProductId.value = null
  bulkAssignChannelIds.value = []
  bulkAssignNote.value = ''
  bulkAssignDialog.value = true
  loadStockProducts()
}

async function doRefill() {
  // 先做前置自检：是否真的有「已绑 + 非故障 + 未满」的货道
  const chs = machine.value?.channels || []
  const refillable = chs.filter(
    c => c.product && c.status !== 'fault' && c.current_stock < c.capacity
  )
  const emptyUnbound = chs.filter(c => !c.product && c.current_stock === 0)
  const fullCount = chs.filter(c => c.product && c.current_stock >= c.capacity).length

  if (refillable.length === 0) {
    // 没东西可补，给用户清晰提示
    let msg = ''
    if (fullCount > 0 && emptyUnbound.length > 0) {
      msg = `已绑货道全部已满（${fullCount} 个），无需补货。` +
            `还有 ${emptyUnbound.length} 个空货道未绑商品，` +
            `请点旁边的「批量投放」给它们铺货。`
    } else if (fullCount > 0) {
      msg = `已绑货道全部已满（${fullCount} 个），无需补货。`
    } else {
      msg = '当前没有已绑商品的货道，请先用「批量投放」给空货道装货。'
    }
    ElMessage({ message: msg, type: 'info', duration: 5000, showClose: true })
    return
  }

  // 有可补货道才弹确认
  await ElMessageBox.confirm(
    `将把 ${refillable.length} 个已绑且未满的货道补到容量上限。仓库不足时按顺序部分补。继续？`,
    '一键补满',
    { confirmButtonText: '确认补满', cancelButtonText: '取消', type: 'info' }
  ).catch(() => null).then(async r => {
    if (!r) return
    bulkLoading.value = true
    try {
      const resp = await bulkRestockMachine(machine.value.id, { note: '一键补满' })
      bulkResult.value = resp
      // 只有真正发生了变化才弹结果 dialog，否则 toast 即可
      if (resp.summary.filled + resp.summary.partial > 0) {
        bulkResultDialog.value = true
      } else {
        ElMessage.info(`已处理 ${resp.summary.channels_processed} 个货道，无可补内容`)
      }
      await reload()
    } finally {
      bulkLoading.value = false
    }
  })
}

async function doBulkAssign() {
  bulkLoading.value = true
  try {
    const resp = await bulkRestockMachine(machine.value.id, {
      product_id: bulkAssignProductId.value,
      channel_ids: bulkAssignChannelIds.value,
      note: bulkAssignNote.value || '批量投放',
    })
    bulkAssignDialog.value = false
    bulkResult.value = resp
    bulkResultDialog.value = true
    await reload()
  } finally {
    bulkLoading.value = false
  }
}

function bulkStatusTag(s) {
  return ({ filled: 'success', partial: 'warning', skipped: 'info' })[s] || 'info'
}
function bulkStatusLabel(s) {
  return ({ filled: '已补满', partial: '部分补', skipped: '跳过' })[s] || s
}
function bulkReasonLabel(r) {
  return ({
    fault: '货道故障',
    full: '货道已满',
    no_product: '货道未绑定礼品',
    conflict_with_existing: '已绑其他礼品且有库存',
    warehouse_empty: '仓库无余量',
    warehouse_limited: '仓库不足，已部分补',
    product_not_found: '礼品不存在',
  })[r] || (r || '')
}

async function loadStockProducts() {
  // 优先项目挂载的礼品；项目无礼品时显示所有有库存礼品
  const data = await listProducts({ has_stock: 1, page_size: 200 })
  stockProducts.value = data.results || data
}

function openConsole() {
  // 后端在 /device/console/<machine_id>/?secret=xxx 提供
  const url = `${window.location.origin.replace(':5173', ':8000')}/device/console/${machine.value.machine_id}/?secret=${encodeURIComponent(machine.value.comm_secret)}`
  window.open(url, '_blank')
}

async function doRemoteDispense() {
  acting.value = true
  try {
    await sendCommand(machine.value.id, {
      cmd: 'motor_run',
      channel: currentChannel.value.channel_code,
      num: remoteNum.value
    })
    ElMessage.success(`已通过 WebSocket 下发 motor_run ${currentChannel.value.channel_code} × ${remoteNum.value}`)
    // 库存变化由设备回报 motor_done 后异步更新，这里不立刻 sync
  } finally {
    acting.value = false
  }
}

function openChannel(ch) {
  currentChannel.value = ch
  activeAction.value = ch.status === 'fault' ? 'fault' : 'restock'
  restockQty.value = Math.max(1, ch.capacity - ch.current_stock)
  restockProductId.value = ch.product || null
  returnQty.value = Math.max(1, ch.current_stock || 1)
  returnNote.value = ''
  faultMessage.value = ''
  channelDialog.value = true
  loadStockProducts()
}

async function doReturn() {
  acting.value = true
  try {
    const updated = await returnChannelToWarehouse(currentChannel.value.id, {
      quantity: returnQty.value,
      note: returnNote.value
    })
    syncChannel(updated)
    const actual = updated.returned ?? returnQty.value
    const tail = updated.unbound ? '，货道已自动解绑礼品' : ''
    ElMessage.success(`回库成功 ${actual} 件，仓库现 ${updated.warehouse_left}${tail}`)
  } finally {
    acting.value = false
  }
}

async function doRestock() {
  acting.value = true
  try {
    const updated = await restockChannel(currentChannel.value.id, {
      quantity: restockQty.value,
      product_id: restockProductId.value
    })
    syncChannel(updated)
    const actual = updated.restocked ?? restockQty.value
    ElMessage.success(`补货成功 ${actual} 件，仓库剩 ${updated.warehouse_left}，货道库存 ${updated.current_stock}`)
    loadStockProducts()
  } finally {
    acting.value = false
  }
}

async function doDispense() {
  acting.value = true
  try {
    const updated = await dispenseChannel(currentChannel.value.id)
    syncChannel(updated)
    ElMessage.success(`测试出货成功，剩余库存 ${updated.current_stock}`)
  } finally {
    acting.value = false
  }
}

async function doMarkFault(isFault) {
  acting.value = true
  try {
    const updated = await setChannelFault(currentChannel.value.id, isFault, faultMessage.value)
    syncChannel(updated)
    ElMessage.success(isFault ? '已标记故障' : '已清除故障')
  } finally {
    acting.value = false
  }
}

function syncChannel(updated) {
  const list = machine.value.channels
  const idx = list.findIndex((c) => c.id === updated.id)
  if (idx >= 0) list[idx] = updated
  currentChannel.value = updated
}

// ----- utils -----
function statusTag(s) {
  return ({ online: 'success', offline: 'info', fault: 'danger' })[s] || 'info'
}
function statusLabel(s) {
  return ({ online: '在线', offline: '离线', fault: '故障' })[s] || s
}
function channelTag(s) {
  return ({ normal: 'success', low: 'warning', empty: 'info', fault: 'danger' })[s] || 'info'
}
function channelLabel(s) {
  return ({ normal: '正常', low: '库存低', empty: '缺货', fault: '故障' })[s] || s
}
function formatTime(iso) {
  return new Date(iso).toLocaleString('zh-CN', { hour12: false })
}
function formatRuntime(seconds) {
  const s = Number(seconds || 0)
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  return `${h}时 ${m}分`
}
</script>

<style lang="scss" scoped>
.device-detail {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.info-card, .matrix-card {
  background: #1a1f2c;
  border: 1px solid #2a3142;
  :deep(.el-card__header) {
    border-bottom: 1px solid #2a3142;
  }
}

.header-row {
  display: flex;
  align-items: center;
  gap: 12px;
  .title { font-size: 15px; color: #e6e6e6; font-weight: 500; }
  .spacer { flex: 1; }
}

.secret {
  background: #0f1419;
  border: 1px solid #2a3142;
  padding: 2px 8px;
  border-radius: 4px;
  font-family: ui-monospace, monospace;
  color: #67c23a;
  word-break: break-all;
  font-size: 12px;
}

.legend {
  display: flex;
  align-items: center;
  gap: 14px;
  color: #909399;
  font-size: 12px;
  .dot {
    display: inline-block;
    width: 10px; height: 10px;
    border-radius: 2px;
    margin-right: 4px;
    vertical-align: middle;
    &.normal { background: #67c23a; }
    &.low    { background: #e6a23c; }
    &.empty  { background: #909399; }
    &.fault  { background: #f56c6c; }
  }
}

.matrix {
  display: flex;
  flex-direction: column;
  gap: 6px;

  .row {
    display: grid;
    grid-template-columns: 40px repeat(10, 1fr);
    gap: 6px;
    &.header .col-head {
      text-align: center;
      color: #909399;
      font-size: 12px;
      padding: 4px 0;
    }
  }
  .row-label {
    color: #909399;
    text-align: center;
    align-self: center;
    font-weight: 600;
  }

  .cell {
    cursor: pointer;
    border-radius: 6px;
    padding: 8px 4px;
    text-align: center;
    color: #fff;
    transition: transform 0.1s, box-shadow 0.1s;
    border: 1px solid transparent;
    &:hover {
      transform: translateY(-1px);
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.4);
      border-color: #fff3;
    }
    &.normal { background: #67c23a; }
    &.low    { background: #e6a23c; }
    &.empty  { background: #606266; }
    &.fault  { background: #f56c6c; }

    .cell-code { font-weight: 600; font-size: 13px; }
    .cell-stock { font-size: 11px; opacity: 0.85; margin-top: 2px; }
  }
}

.hint {
  margin-left: 12px;
  color: #909399;
  font-size: 12px;
}

.muted { color: #909399; font-size: 12px; }

.bulk-channel-toolbar {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.channel-grid {
  background: #131822;
  border: 1px solid #2a3142;
  border-radius: 6px;
  padding: 10px;
  max-height: 220px;
  overflow-y: auto;
  :deep(.el-checkbox) {
    width: 90px;
    margin-right: 0;
    margin-bottom: 4px;
  }
}

.bulk-summary {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  margin-bottom: 16px;
}
h4 { color: #c0c4cc; margin: 16px 0 8px; font-size: 13px; }

.unset-row {
  color: #606266;
  font-size: 13px;
  padding: 16px 0;
  text-align: center;
}

/* Phase 5.3 QT 注册信息 */
.qt-info {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.qt-field {
  display: flex;
  align-items: center;
  gap: 10px;
}
.qt-label {
  color: #909399;
  font-size: 13px;
  white-space: nowrap;
  min-width: 80px;
}
.qt-hint {
  color: #606266;
  font-size: 12px;
  margin-left: 4px;
}
.qt-info .secret.url {
  font-size: 11px;
  max-width: 520px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* Phase 5.1 访问地址 */
.urls-block {
  display: flex; flex-direction: column; gap: 8px;
  margin-bottom: 14px;
}
</style>
