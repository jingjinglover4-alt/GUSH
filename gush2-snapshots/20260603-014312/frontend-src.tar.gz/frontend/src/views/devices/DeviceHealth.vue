<template>
  <div v-loading="loading" class="dh">
    <el-card shadow="never">
      <div class="hdr">
        <span class="title">设备健康看板</span>
        <span class="hint">心跳超时 = {{ data?.summary?.heartbeat_timeout_seconds ?? 90 }} 秒</span>
        <div style="flex:1" />
        <el-button :icon="Refresh" @click="load">刷新</el-button>
      </div>
    </el-card>

    <!-- 总览 KPI -->
    <div class="kpi-grid">
      <div class="kpi-card primary">
        <div class="kpi-label">设备总数</div>
        <div class="kpi-value">{{ data?.summary?.total ?? 0 }}</div>
      </div>
      <div class="kpi-card success">
        <div class="kpi-label">在线</div>
        <div class="kpi-value">{{ data?.summary?.online ?? 0 }}</div>
        <div class="kpi-sub">在线率 {{ data?.summary?.online_rate ?? 0 }}%</div>
      </div>
      <div class="kpi-card info">
        <div class="kpi-label">离线</div>
        <div class="kpi-value">{{ data?.summary?.offline ?? 0 }}</div>
      </div>
      <div class="kpi-card danger">
        <div class="kpi-label">故障</div>
        <div class="kpi-value">{{ data?.summary?.fault ?? 0 }}</div>
      </div>
      <div class="kpi-card warning">
        <div class="kpi-label">未解决故障</div>
        <div class="kpi-value">{{ data?.summary?.fault_open ?? 0 }}</div>
        <div class="kpi-sub">今日新增 {{ data?.summary?.fault_today ?? 0 }}</div>
      </div>
    </div>

    <!-- 心跳趋势 -->
    <el-card shadow="never">
      <template #header><span class="card-title">近 7 日心跳量</span></template>
      <div ref="trendEl" style="width:100%; height:280px"></div>
    </el-card>

    <!-- 设备明细 -->
    <el-card shadow="never">
      <template #header>
        <span class="card-title">设备明细</span>
      </template>
      <el-table :data="data?.machines || []" stripe size="small" empty-text="暂无设备">
        <el-table-column prop="machine_id" label="设备编号" width="130" />
        <el-table-column prop="name" label="名称" />
        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag size="small" :type="statusTag(row.status)">
              <span class="dot" :class="row.status" />
              {{ statusLabel(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="最近心跳" width="180">
          <template #default="{ row }">
            <div v-if="row.last_heartbeat_at" :class="{ stale: row.stale }">
              {{ formatTime(row.last_heartbeat_at) }}
              <div class="sec-since">{{ formatSince(row.seconds_since_heartbeat) }} 前</div>
            </div>
            <span v-else style="color: var(--el-text-color-secondary)">从未心跳</span>
          </template>
        </el-table-column>
        <el-table-column label="信号" width="100">
          <template #default="{ row }">
            <span v-if="row.signal_strength > 0">{{ row.signal_strength }}%</span>
            <span v-else style="color: var(--el-text-color-secondary)">—</span>
            <span v-if="row.network_type" class="hint" style="margin-left:6px">{{ row.network_type }}</span>
          </template>
        </el-table-column>
        <el-table-column label="累计运行" width="120">
          <template #default="{ row }">{{ formatRuntime(row.runtime_seconds) }}</template>
        </el-table-column>
        <el-table-column label="货道故障" width="100">
          <template #default="{ row }">
            <el-tag v-if="row.channel_fault_count > 0" type="danger" size="small">
              {{ row.channel_fault_count }} 个
            </el-tag>
            <span v-else style="color: var(--el-text-color-secondary)">—</span>
          </template>
        </el-table-column>
        <el-table-column label="未解决故障" width="120">
          <template #default="{ row }">
            <el-tag v-if="row.open_fault_count > 0" type="warning" size="small">
              {{ row.open_fault_count }} 个
            </el-tag>
            <span v-else style="color: var(--el-text-color-secondary)">—</span>
          </template>
        </el-table-column>
        <el-table-column prop="firmware_version" label="固件" width="100">
          <template #default="{ row }">
            <span v-if="row.firmware_version">{{ row.firmware_version }}</span>
            <span v-else style="color: var(--el-text-color-secondary)">—</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="100">
          <template #default="{ row }">
            <el-button size="small" link type="primary" @click="$router.push(`/devices/${row.id}`)">查看</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 故障 Top -->
    <el-card v-if="data?.fault_rank?.length" shadow="never">
      <template #header><span class="card-title">未解决故障 Top 10</span></template>
      <el-table :data="data.fault_rank" stripe size="small">
        <el-table-column prop="machine_id" label="设备" width="130" />
        <el-table-column prop="name" label="名称" />
        <el-table-column label="未解决故障数" width="130" align="right">
          <template #default="{ row }">
            <el-tag type="danger" size="small">{{ row.open_faults }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="100">
          <template #default="{ row }">
            <el-button size="small" link @click="$router.push(`/devices/${row.id}`)">查看</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, nextTick } from 'vue'
import { Refresh } from '@element-plus/icons-vue'
import * as echarts from 'echarts'
import { deviceHealthOverview } from '@/api/devices'

const loading = ref(false)
const data = ref(null)
const trendEl = ref(null)
let trendChart = null

function statusTag(s) { return ({ online: 'success', offline: 'info', fault: 'danger' })[s] || '' }
function statusLabel(s) { return ({ online: '在线', offline: '离线', fault: '故障' })[s] || s }

function formatTime(s) {
  if (!s) return ''
  return new Date(s).toLocaleString('zh-CN', { hour12: false }).replace(/\//g, '-')
}
function formatSince(sec) {
  if (sec == null) return '?'
  if (sec < 60) return `${sec} 秒`
  if (sec < 3600) return `${Math.floor(sec / 60)} 分`
  if (sec < 86400) return `${Math.floor(sec / 3600)} 小时`
  return `${Math.floor(sec / 86400)} 天`
}
function formatRuntime(sec) {
  if (!sec) return '—'
  const days = Math.floor(sec / 86400)
  const hours = Math.floor((sec % 86400) / 3600)
  if (days > 0) return `${days}天${hours}时`
  if (hours > 0) return `${hours}时`
  return `${Math.floor(sec / 60)}分`
}

async function load() {
  loading.value = true
  try {
    data.value = await deviceHealthOverview()
    await nextTick()
    renderTrend()
  } finally {
    loading.value = false
  }
}

function renderTrend() {
  if (!trendEl.value || !data.value) return
  if (!trendChart) trendChart = echarts.init(trendEl.value)
  const trend = data.value.trend || []
  trendChart.setOption({
    tooltip: { trigger: 'axis' },
    grid: { left: 40, right: 20, top: 20, bottom: 40 },
    xAxis: { type: 'category', data: trend.map(t => t.date.slice(5)) },
    yAxis: { type: 'value', minInterval: 1 },
    series: [{
      type: 'bar',
      data: trend.map(t => t.heartbeats),
      itemStyle: { color: '#67c23a' },
    }],
  }, true)
}

function onResize() { trendChart?.resize() }
onMounted(() => { load(); window.addEventListener('resize', onResize) })
onUnmounted(() => { window.removeEventListener('resize', onResize); trendChart?.dispose() })
</script>

<style scoped>
.dh { display: flex; flex-direction: column; gap: 14px; }
.hdr { display: flex; align-items: center; gap: 12px; }
.hdr .title { font-size: 16px; font-weight: 600; }
.hdr .hint { color: var(--el-text-color-secondary); font-size: 12px; }
.card-title { font-size: 14px; font-weight: 600; }

.kpi-grid {
  display: grid;
  grid-template-columns: repeat(5, minmax(0, 1fr));
  gap: 12px;
}
.kpi-card {
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-light);
  border-radius: 10px;
  padding: 14px 18px;
}
.kpi-card.primary { border-left: 4px solid var(--el-color-primary); }
.kpi-card.success { border-left: 4px solid var(--el-color-success); }
.kpi-card.info    { border-left: 4px solid var(--el-color-info); }
.kpi-card.warning { border-left: 4px solid var(--el-color-warning); }
.kpi-card.danger  { border-left: 4px solid var(--el-color-danger); }
.kpi-label { color: var(--el-text-color-secondary); font-size: 13px; }
.kpi-value { font-size: 28px; font-weight: 700; line-height: 1.2; margin-top: 4px; }
.kpi-sub { color: var(--el-text-color-secondary); font-size: 12px; margin-top: 4px; }

.dot {
  display: inline-block; width: 6px; height: 6px; border-radius: 50%;
  background: #ccc; margin-right: 4px; vertical-align: middle;
}
.dot.online { background: #67c23a; box-shadow: 0 0 6px #67c23a; }
.dot.offline { background: #909399; }
.dot.fault { background: #f56c6c; }

.stale { color: var(--el-color-danger); }
.sec-since { color: var(--el-text-color-secondary); font-size: 11px; }

@media (max-width: 1100px) {
  .kpi-grid { grid-template-columns: repeat(2, 1fr); }
}
</style>
