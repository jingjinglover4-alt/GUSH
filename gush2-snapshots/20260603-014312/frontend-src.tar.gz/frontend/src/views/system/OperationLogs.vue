<template>
  <div class="logs-page">
    <el-card class="filter-card">
      <el-input v-model="filter.username" placeholder="用户名" clearable style="width:180px" />
      <el-select v-model="filter.method" placeholder="方法" clearable style="width:120px; margin-left:8px">
        <el-option label="POST" value="POST" />
        <el-option label="PUT" value="PUT" />
        <el-option label="PATCH" value="PATCH" />
        <el-option label="DELETE" value="DELETE" />
      </el-select>
      <el-input v-model="filter.path" placeholder="路径包含" clearable style="width:240px; margin-left:8px" />
      <el-button type="primary" style="margin-left:8px" @click="load">查询</el-button>
      <el-button @click="reset">重置</el-button>
    </el-card>

    <el-card style="margin-top:16px">
      <el-table :data="list" v-loading="loading" stripe>
        <el-table-column prop="created_at" label="时间" width="170" />
        <el-table-column prop="username" label="用户" width="120" />
        <el-table-column prop="method" label="方法" width="80">
          <template #default="{ row }">
            <el-tag :type="tagType(row.method)" size="small">{{ row.method }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="path" label="路径" min-width="240" show-overflow-tooltip />
        <el-table-column prop="status_code" label="状态码" width="80">
          <template #default="{ row }">
            <el-tag :type="row.status_code < 400 ? 'success' : 'danger'" size="small">
              {{ row.status_code }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="ip" label="IP" width="140" />
        <el-table-column prop="user_agent" label="UA" min-width="200" show-overflow-tooltip />
      </el-table>

      <el-pagination
        v-if="total > pageSize"
        :current-page="page"
        :page-size="pageSize"
        :total="total"
        layout="prev, pager, next, total"
        style="margin-top:16px; justify-content:flex-end"
        @current-change="onPage"
      />
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { ElMessage } from 'element-plus'
import { listOperationLogs } from '@/api/operations'

const list = ref([])
const loading = ref(false)
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)

const filter = reactive({ username: '', method: '', path: '' })

function tagType(m) {
  return ({ POST: 'success', PUT: 'warning', PATCH: 'warning', DELETE: 'danger' })[m] || 'info'
}

async function load() {
  loading.value = true
  try {
    const params = { page: page.value }
    if (filter.username) params.username = filter.username
    if (filter.method) params.method = filter.method
    if (filter.path) params.search = filter.path
    const res = await listOperationLogs(params)
    if (Array.isArray(res)) {
      list.value = res; total.value = res.length
    } else {
      list.value = res.results || []
      total.value = res.count || 0
    }
  } catch (e) {
    ElMessage.error('加载失败：' + (e?.response?.data?.detail || e.message))
  } finally {
    loading.value = false
  }
}

function onPage(p) { page.value = p; load() }
function reset() {
  filter.username = ''; filter.method = ''; filter.path = ''
  page.value = 1; load()
}

load()
</script>

<style lang="scss" scoped>
.logs-page { padding: 4px; }
</style>
