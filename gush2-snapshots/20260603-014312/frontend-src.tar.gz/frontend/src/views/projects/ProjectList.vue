<template>
  <div class="project-list">
    <div class="toolbar">
      <el-input
        v-model="filters.search"
        placeholder="搜索项目名称"
        clearable
        style="width: 240px"
        @keyup.enter="reload"
        @clear="reload"
      >
        <template #prefix><el-icon><Search /></el-icon></template>
      </el-input>
      <el-select v-model="filters.status" placeholder="全部状态" clearable style="width: 140px" @change="reload">
        <el-option label="草稿" value="draft" />
        <el-option label="进行中" value="running" />
        <el-option label="已暂停" value="paused" />
        <el-option label="已结束" value="finished" />
      </el-select>
      <el-button :icon="Refresh" @click="reload">刷新</el-button>
      <div class="spacer" />
      <el-button type="primary" :icon="Plus" @click="openCreate">新建项目</el-button>
    </div>

    <el-table v-loading="loading" :data="rows" stripe style="margin-top: 16px"
              @row-dblclick="(r) => goDetail(r.id)">
      <el-table-column prop="name" label="项目名称" min-width="180" />
      <el-table-column label="状态" width="100">
        <template #default="{ row }">
          <el-tag :type="statusTag(row.status)" size="small">{{ statusLabel(row.status) }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="时间" width="200">
        <template #default="{ row }">
          <div style="font-size:12px;color:#909399">{{ formatDate(row.starts_at) }}</div>
          <div style="font-size:12px;color:#909399">至 {{ formatDate(row.ends_at) }}</div>
        </template>
      </el-table-column>
      <el-table-column label="设备数" width="100">
        <template #default="{ row }">{{ row.machine_count }}</template>
      </el-table-column>
      <el-table-column label="兑换码 (已用/总数)" width="160">
        <template #default="{ row }">{{ row.code_used }} / {{ row.code_total }}</template>
      </el-table-column>
      <el-table-column label="码长度 / 有效秒数" width="160">
        <template #default="{ row }">{{ row.code_length }} 位 / {{ row.code_validity_seconds }} 秒</template>
      </el-table-column>
      <el-table-column label="操作" width="220" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click="goDetail(row.id)">详情</el-button>
          <el-button link type="warning" @click="openEdit(row)">编辑</el-button>
          <el-popconfirm title="确认删除该项目？兑换码会一并清除" @confirm="remove(row)">
            <template #reference><el-button link type="danger">删除</el-button></template>
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>

    <!-- 新建 / 编辑 -->
    <el-dialog v-model="dialogVisible" :title="editing ? '编辑项目' : '新建项目'" width="560px">
      <el-form ref="formRef" :model="form" :rules="rules" label-width="100px">
        <el-form-item label="项目名称" prop="name">
          <el-input v-model="form.name" maxlength="64" />
        </el-form-item>
        <el-form-item label="项目描述">
          <el-input v-model="form.description" type="textarea" :rows="2" maxlength="500" />
        </el-form-item>
        <el-form-item label="开始时间" prop="starts_at">
          <el-date-picker v-model="form.starts_at" type="datetime" value-format="YYYY-MM-DDTHH:mm:ss" style="width:100%" />
        </el-form-item>
        <el-form-item label="结束时间" prop="ends_at">
          <el-date-picker v-model="form.ends_at" type="datetime" value-format="YYYY-MM-DDTHH:mm:ss" style="width:100%" />
        </el-form-item>
        <el-form-item label="码长度">
          <el-input-number v-model="form.code_length" :min="4" :max="16" />
        </el-form-item>
        <el-form-item label="有效秒数">
          <el-input-number v-model="form.code_validity_seconds" :min="60" :max="600" />
        </el-form-item>
        <el-form-item label="每人上限">
          <el-input-number v-model="form.max_per_user" :min="1" :max="100" />
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="form.status" style="width:100%">
            <el-option label="草稿" value="draft" />
            <el-option label="进行中" value="running" />
            <el-option label="已暂停" value="paused" />
            <el-option label="已结束" value="finished" />
          </el-select>
        </el-form-item>
        <el-form-item label="活动规则">
          <el-input v-model="form.rules_text" type="textarea" :rows="3" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="submit">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { reactive, ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Search, Refresh, Plus } from '@element-plus/icons-vue'
import { listProjects, createProject, updateProject, deleteProject } from '@/api/projects'

const router = useRouter()
const loading = ref(false)
const rows = ref([])
const filters = reactive({ search: '', status: '' })

async function reload() {
  loading.value = true
  try {
    const data = await listProjects({
      search: filters.search || undefined,
      status: filters.status || undefined
    })
    rows.value = Array.isArray(data) ? data : (data.results || [])
  } finally {
    loading.value = false
  }
}
onMounted(reload)

function goDetail(id) { router.push(`/projects/${id}`) }
function statusTag(s) { return ({ draft:'info', running:'success', paused:'warning', finished:'' })[s] || 'info' }
function statusLabel(s) { return ({ draft:'草稿', running:'进行中', paused:'已暂停', finished:'已结束' })[s] || s }
function formatDate(iso) { return iso ? new Date(iso).toLocaleString('zh-CN', { hour12: false }) : '—' }

// ---- 新建 / 编辑 ----
const dialogVisible = ref(false)
const editing = ref(null)
const saving = ref(false)
const formRef = ref()
const form = reactive({
  name: '', description: '',
  starts_at: '', ends_at: '',
  code_length: 8, code_validity_seconds: 60, max_per_user: 1,
  status: 'draft', rules_text: ''
})
const rules = {
  name: [{ required: true, message: '请输入项目名称', trigger: 'blur' }],
  starts_at: [{ required: true, message: '请选择开始时间', trigger: 'change' }],
  ends_at: [{ required: true, message: '请选择结束时间', trigger: 'change' }]
}
function openCreate() {
  editing.value = null
  Object.assign(form, {
    name: '', description: '',
    starts_at: '', ends_at: '',
    code_length: 8, code_validity_seconds: 60, max_per_user: 1,
    status: 'draft', rules_text: ''
  })
  dialogVisible.value = true
}
function openEdit(row) {
  editing.value = row
  Object.assign(form, {
    name: row.name, description: row.description || '',
    starts_at: row.starts_at, ends_at: row.ends_at,
    code_length: row.code_length, code_validity_seconds: row.code_validity_seconds,
    max_per_user: row.max_per_user, status: row.status, rules_text: row.rules_text || ''
  })
  dialogVisible.value = true
}
async function submit() {
  const ok = await formRef.value?.validate().catch(() => false)
  if (!ok) return
  saving.value = true
  try {
    if (editing.value) {
      await updateProject(editing.value.id, { ...form })
      ElMessage.success('保存成功')
    } else {
      await createProject({ ...form })
      ElMessage.success('项目已创建')
    }
    dialogVisible.value = false
    await reload()
  } finally {
    saving.value = false
  }
}
async function remove(row) {
  await deleteProject(row.id)
  ElMessage.success('已删除')
  await reload()
}
</script>

<style lang="scss" scoped>
.project-list .toolbar { display:flex; gap:12px; align-items:center; }
.project-list .toolbar .spacer { flex:1; }
</style>
