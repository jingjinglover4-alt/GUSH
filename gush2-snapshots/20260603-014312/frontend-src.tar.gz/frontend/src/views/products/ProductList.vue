<template>
  <div class="product-page">
    <el-card class="filter-card">
      <el-input
        v-model="search"
        placeholder="按名称 / SKU / 品牌搜索"
        clearable
        style="width: 280px"
        @keyup.enter="load"
        @clear="load"
      />
      <el-checkbox v-model="onlyHasStock" @change="load" style="margin-left:12px">仅看仓库有货</el-checkbox>
      <el-button type="primary" @click="load">查询</el-button>
      <el-button type="success" @click="openCreate">新建礼品</el-button>
    </el-card>

    <el-card style="margin-top: 16px">
      <el-table :data="list" v-loading="loading" stripe>
        <el-table-column label="封面" width="72">
          <template #default="{ row }">
            <el-image
              v-if="row.image_url"
              :src="row.image_url"
              :preview-src-list="[row.image_url]"
              fit="cover"
              style="width: 44px; height: 44px; border-radius: 4px"
            />
            <span v-else style="color:#666">—</span>
          </template>
        </el-table-column>
        <el-table-column prop="sku" label="SKU" width="120" />
        <el-table-column prop="name" label="名称" min-width="140" />
        <el-table-column prop="brand" label="品牌" width="100" />

        <el-table-column label="仓库" width="80" align="right">
          <template #default="{ row }">
            <span :class="stockClass(row.total_stock)">{{ row.total_stock }}</span>
          </template>
        </el-table-column>
        <el-table-column label="在机" width="80" align="right">
          <template #default="{ row }">{{ row.on_machine_stock }}</template>
        </el-table-column>
        <el-table-column label="已派" width="80" align="right">
          <template #default="{ row }">{{ row.dispensed_count }}</template>
        </el-table-column>
        <el-table-column label="剩余" width="80" align="right">
          <template #default="{ row }">
            <b :style="{color: row.remaining_stock > 0 ? '#67c23a' : '#f56c6c'}">
              {{ row.remaining_stock }}
            </b>
          </template>
        </el-table-column>

        <el-table-column label="在机设备" min-width="220">
          <template #default="{ row }">
            <span v-if="!row.machines?.length" style="color:#606266">未投放</span>
            <el-tooltip
              v-for="m in row.machines"
              :key="m.machine_id"
              :content="`${m.name} · 货道 ${m.channel_codes.join(',')} · 共 ${m.stock_sum} 件`"
              placement="top"
            >
              <el-tag
                :type="m.status === 'online' ? 'success' : (m.status === 'fault' ? 'danger' : 'info')"
                size="small"
                effect="plain"
                style="margin: 2px 4px 2px 0; cursor:pointer"
                @click="$router.push(`/devices/${m.id}`)"
              >
                {{ m.machine_id }}
                <span style="opacity:.7; margin-left:4px">×{{ m.stock_sum }}</span>
              </el-tag>
            </el-tooltip>
          </template>
        </el-table-column>

        <el-table-column prop="channel_count" label="货道数" width="76" align="right" />

        <el-table-column label="操作" width="240">
          <template #default="{ row }">
            <el-button size="small" type="primary" link @click="openDetail(row)">详情</el-button>
            <el-button size="small" type="success" @click="openInbound(row)">入库</el-button>
            <el-button size="small" @click="openEdit(row)">编辑</el-button>
            <el-button size="small" type="danger" @click="onDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        v-if="total > pageSize"
        :current-page="page"
        :page-size="pageSize"
        :total="total"
        layout="prev, pager, next, total"
        style="margin-top: 16px; justify-content: flex-end"
        @current-change="onPage"
      />
    </el-card>

    <!-- ============ 新建/编辑 ============ -->
    <el-dialog v-model="dialog.visible" :title="dialog.id ? '编辑礼品' : '新建礼品'" width="520px">
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
        <el-form-item label="SKU" prop="sku">
          <el-input v-model="form.sku" placeholder="唯一编码" />
        </el-form-item>
        <el-form-item label="名称" prop="name">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="品牌">
          <el-input v-model="form.brand" />
        </el-form-item>
        <el-form-item label="低库存阈值">
          <el-input-number v-model="form.low_stock_threshold" :min="0" :max="100" />
        </el-form-item>
        <el-form-item label="描述">
          <el-input v-model="form.description" type="textarea" :rows="3" />
        </el-form-item>
        <el-form-item label="封面">
          <el-upload
            :auto-upload="false"
            :show-file-list="true"
            :limit="1"
            :on-change="onFile"
            :on-remove="() => (form._file = null)"
            list-type="picture"
            accept="image/*"
          >
            <el-button>选择图片</el-button>
          </el-upload>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialog.visible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="onSave">保存</el-button>
      </template>
    </el-dialog>

    <!-- ============ 入库 ============ -->
    <el-dialog v-model="inbound.visible" :title="`入库 - ${inbound.row?.name || ''}`" width="420px">
      <p style="color:#909399; margin: 0 0 12px">
        当前仓库库存：<b>{{ inbound.row?.total_stock ?? 0 }}</b>
      </p>
      <el-form label-width="80px">
        <el-form-item label="入库数量">
          <el-input-number v-model="inbound.quantity" :min="1" :max="100000" />
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="inbound.note" placeholder="例：首批/补货/退仓" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="inbound.visible = false">取消</el-button>
        <el-button type="primary" :loading="inbound.saving" @click="onInbound">确认入库</el-button>
      </template>
    </el-dialog>

    <!-- ============ 详情抽屉 ============ -->
    <el-drawer v-model="detail.visible" :title="detail.data?.name || '礼品详情'" size="640px">
      <div v-if="detail.data" class="detail-body">
        <el-descriptions :column="2" border>
          <el-descriptions-item label="SKU">{{ detail.data.sku }}</el-descriptions-item>
          <el-descriptions-item label="品牌">{{ detail.data.brand || '—' }}</el-descriptions-item>
          <el-descriptions-item label="仓库库存">
            <b>{{ detail.data.total_stock }}</b>
          </el-descriptions-item>
          <el-descriptions-item label="在机库存">{{ detail.data.on_machine_stock }}</el-descriptions-item>
          <el-descriptions-item label="累计已派">{{ detail.data.dispensed_count }}</el-descriptions-item>
          <el-descriptions-item label="剩余">
            <b style="color:#67c23a">{{ detail.data.remaining_stock }}</b>
          </el-descriptions-item>
        </el-descriptions>

        <h4 class="sec">所属项目（{{ detail.data.projects?.length || 0 }}）</h4>
        <div v-if="detail.data.projects?.length">
          <el-tag v-for="p in detail.data.projects" :key="p.id" style="margin-right:6px">
            {{ p.name }}
          </el-tag>
        </div>
        <el-empty v-else description="尚未加入任何项目" :image-size="60" />

        <h4 class="sec">
          在机分布（{{ detail.data.machines?.length || 0 }} 台设备 · {{ detail.data.channels?.length || 0 }} 个货道）
        </h4>
        <el-empty v-if="!detail.data.machines?.length" description="尚未投放到任何设备" :image-size="60" />
        <div v-else>
          <el-card v-for="m in detail.data.machines" :key="m.machine_id"
                   shadow="never" class="machine-card">
            <div class="machine-head">
              <el-link type="primary" @click="$router.push(`/devices/${m.id}`)">
                {{ m.machine_id }} · {{ m.name }}
              </el-link>
              <el-tag :type="m.status === 'online' ? 'success' : (m.status === 'fault' ? 'danger' : 'info')" size="small">
                {{ ({online:'在线', offline:'离线', fault:'故障'})[m.status] || m.status }}
              </el-tag>
              <div class="spacer" />
              <span style="color:#909399">合计 <b style="color:#67c23a">{{ m.stock_sum }}</b> 件</span>
            </div>
            <el-table :data="channelsOfMachine(m.machine_id)" size="small" stripe>
              <el-table-column prop="channel_code" label="货道" width="70" />
              <el-table-column label="库存" width="90">
                <template #default="{ row }">{{ row.current_stock }} / {{ row.capacity }}</template>
              </el-table-column>
              <el-table-column prop="status" label="状态" width="80">
                <template #default="{ row }">
                  <el-tag :type="statusType(row.status)" size="small">{{ statusLabel(row.status) }}</el-tag>
                </template>
              </el-table-column>
            </el-table>
          </el-card>
        </div>
      </div>
    </el-drawer>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  listProducts, getProduct,
  createProduct, updateProduct, deleteProduct,
  inboundStock
} from '@/api/products'

const list = ref([])
const loading = ref(false)
const saving = ref(false)
const search = ref('')
const onlyHasStock = ref(false)
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)

const formRef = ref(null)
const dialog = reactive({ visible: false, id: null })
const form = reactive({
  sku: '', name: '', brand: '',
  low_stock_threshold: 1, description: '', _file: null
})
const rules = {
  sku: [{ required: true, message: '请输入 SKU', trigger: 'blur' }],
  name: [{ required: true, message: '请输入名称', trigger: 'blur' }]
}

const inbound = reactive({ visible: false, row: null, quantity: 100, note: '', saving: false })
const detail = reactive({ visible: false, data: null })

function stockClass(n) {
  if (n <= 0) return 'stock-zero'
  return ''
}
function statusType(s) {
  return ({ normal: 'success', low: 'warning', empty: 'danger', fault: 'danger' })[s] || 'info'
}
function statusLabel(s) {
  return ({ normal: '正常', low: '库存低', empty: '缺货', fault: '故障' })[s] || s
}

async function load() {
  loading.value = true
  try {
    const params = { page: page.value, search: search.value }
    if (onlyHasStock.value) params.has_stock = 1
    const res = await listProducts(params)
    if (Array.isArray(res)) {
      list.value = res; total.value = res.length
    } else {
      list.value = res.results || []
      total.value = res.count || 0
    }
  } catch (e) {
    ElMessage.error('加载失败：' + (e?.response?.data?.detail || e.message))
  } finally {
    loading.value = false
  }
}
function onPage(p) { page.value = p; load() }

function resetForm() {
  Object.assign(form, {
    sku: '', name: '', brand: '',
    low_stock_threshold: 1, description: '', _file: null
  })
}
function openCreate() { resetForm(); dialog.id = null; dialog.visible = true }
function openEdit(row) {
  resetForm()
  Object.assign(form, {
    sku: row.sku, name: row.name, brand: row.brand,
    low_stock_threshold: row.low_stock_threshold,
    description: row.description, _file: null
  })
  dialog.id = row.id
  dialog.visible = true
}
function onFile(file) { form._file = file.raw }

async function onSave() {
  await formRef.value?.validate().catch(() => null)
  saving.value = true
  try {
    const fd = new FormData()
    fd.append('sku', form.sku)
    fd.append('name', form.name)
    fd.append('brand', form.brand || '')
    fd.append('low_stock_threshold', form.low_stock_threshold)
    fd.append('description', form.description || '')
    if (form._file) fd.append('image', form._file)
    if (dialog.id) {
      await updateProduct(dialog.id, fd)
      ElMessage.success('已更新')
    } else {
      await createProduct(fd)
      ElMessage.success('已创建')
    }
    dialog.visible = false
    load()
  } catch (e) {
    ElMessage.error('保存失败：' + (e?.response?.data?.detail || JSON.stringify(e?.response?.data || {}) || e.message))
  } finally {
    saving.value = false
  }
}

async function onDelete(row) {
  try {
    await ElMessageBox.confirm(`确认删除礼品「${row.name}」？该操作不可撤销`, '确认', { type: 'warning' })
  } catch { return }
  try {
    await deleteProduct(row.id)
    ElMessage.success('已删除')
    load()
  } catch (e) {
    ElMessage.error('删除失败：' + (e?.response?.data?.detail || e.message))
  }
}

// ---- 入库 ----
function openInbound(row) {
  inbound.row = row
  inbound.quantity = 100
  inbound.note = ''
  inbound.visible = true
}
async function onInbound() {
  inbound.saving = true
  try {
    await inboundStock(inbound.row.id, { quantity: inbound.quantity, note: inbound.note })
    ElMessage.success(`已入库 ${inbound.quantity} 件`)
    inbound.visible = false
    load()
  } catch (e) {
    ElMessage.error('入库失败：' + (e?.response?.data?.detail || e.message))
  } finally {
    inbound.saving = false
  }
}

// ---- 详情 ----
async function openDetail(row) {
  detail.visible = true
  detail.data = null
  try {
    detail.data = await getProduct(row.id)
  } catch (e) {
    ElMessage.error('加载详情失败：' + e.message)
  }
}

function channelsOfMachine(machineId) {
  return (detail.data?.channels || []).filter(c => c.machine_id === machineId)
}

load()
</script>

<style lang="scss" scoped>
.product-page { padding: 4px; }
.filter-card .el-button, .filter-card .el-checkbox { margin-left: 12px; }

.stock-zero { color: #f56c6c; }

.detail-body {
  padding: 0 4px;
  .sec {
    margin: 20px 0 10px;
    font-size: 14px;
    color: #c0c4cc;
    border-left: 3px solid #409eff;
    padding-left: 8px;
  }
}
.machine-card {
  background: #131822;
  border: 1px solid #2a3142;
  margin-bottom: 12px;
  :deep(.el-card__body) { padding: 12px; }
}
.machine-head {
  display: flex; align-items: center; gap: 10px;
  margin-bottom: 8px;
  .spacer { flex: 1; }
}
</style>
