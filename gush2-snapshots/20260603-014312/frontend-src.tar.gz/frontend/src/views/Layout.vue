<template>
  <el-container class="layout">
    <!-- 侧边栏 -->
    <el-aside :width="collapsed ? '64px' : '220px'" class="sidebar">
      <div class="logo" @click="$router.push('/')">
        <div class="logo-icon">G</div>
        <span v-show="!collapsed" class="logo-text">GUSH 2.0</span>
      </div>

      <el-menu
        :default-active="$route.path"
        :collapse="collapsed"
        router
        background-color="#1a1f2c"
        text-color="#c0c4cc"
        active-text-color="#409eff"
      >
        <template v-for="r in menuRoutes" :key="r.path">
          <el-menu-item :index="'/' + r.path">
            <el-icon><component :is="r.meta.icon" /></el-icon>
            <template #title>
              {{ r.meta.title }}
              <el-tag
                v-if="r.meta.stage"
                size="small"
                type="info"
                style="margin-left: 6px"
              >
                阶段{{ r.meta.stage }}
              </el-tag>
            </template>
          </el-menu-item>
        </template>
      </el-menu>
    </el-aside>

    <el-container>
      <!-- 顶栏 -->
      <el-header class="header">
        <div class="header-left">
          <el-button
            link
            :icon="collapsed ? Expand : Fold"
            @click="collapsed = !collapsed"
          />
          <span class="page-title">{{ $route.meta.title || '管理后台' }}</span>
        </div>

        <div class="header-right">
          <el-dropdown @command="onCommand">
            <span class="user-trigger">
              <el-avatar :size="32">{{ avatarText }}</el-avatar>
              <span class="username">{{ auth.user?.username }}</span>
              <el-tag size="small" type="warning">{{ auth.roleLabel }}</el-tag>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="logout">
                  <el-icon><SwitchButton /></el-icon> 退出登录
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </el-header>

      <!-- 主内容 -->
      <el-main class="main">
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessageBox } from 'element-plus'
import { Fold, Expand, SwitchButton } from '@element-plus/icons-vue'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const auth = useAuthStore()
const collapsed = ref(false)

const menuRoutes = router.getRoutes()
  .filter(r => r.meta?.title && r.path !== '/' && !r.meta?.hidden && !r.path.includes(':'))
  .map(r => ({ path: r.path.replace(/^\//, ''), meta: r.meta }))

const avatarText = computed(() => (auth.user?.username || 'U').charAt(0).toUpperCase())

async function onCommand(cmd) {
  if (cmd === 'logout') {
    await ElMessageBox.confirm('确定退出登录吗？', '提示', { type: 'warning' })
      .catch(() => null)
      .then(r => r && doLogout())
  }
}

function doLogout() {
  auth.clear()
  router.replace('/login')
}
</script>

<style lang="scss" scoped>
.layout {
  height: 100vh;
}

.sidebar {
  background: #1a1f2c;
  border-right: 1px solid #2a3142;
  transition: width 0.2s;
  overflow: hidden;

  .logo {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 16px 18px;
    border-bottom: 1px solid #2a3142;
    cursor: pointer;

    .logo-icon {
      width: 32px;
      height: 32px;
      border-radius: 8px;
      background: linear-gradient(135deg, #409eff, #67c23a);
      color: #fff;
      font-weight: 700;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .logo-text {
      color: #fff;
      font-weight: 600;
      font-size: 16px;
    }
  }

  :deep(.el-menu) {
    border-right: none;
  }
}

.header {
  background: #1a1f2c;
  border-bottom: 1px solid #2a3142;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;

  .header-left {
    display: flex;
    align-items: center;
    gap: 16px;
    .page-title {
      color: #e6e6e6;
      font-size: 16px;
    }
  }

  .user-trigger {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
    .username { color: #e6e6e6; }
  }
}

.main {
  background: #0f1419;
  padding: 20px;
  overflow-y: auto;
}
</style>
