<template>
  <div class="access-url-card">
    <div class="url-row">
      <div class="url-label">
        <el-icon><Link /></el-icon>
        <span>{{ label }}</span>
      </div>
      <div class="url-text" :title="url">{{ url }}</div>
      <el-button :icon="CopyDocument" size="small" plain @click="copy">复制</el-button>
      <el-button :icon="Picture" size="small" plain @click="showQr">二维码</el-button>
      <el-button :icon="Position" size="small" plain @click="openUrl">访问</el-button>
    </div>

    <el-dialog v-model="qrOpen" :title="`${label} · 二维码`" width="400px">
      <div style="text-align:center">
        <img :src="qrSrc" :alt="label"
             style="width:300px; height:300px; background:#fff; padding:8px; border-radius:8px" />
        <div class="qr-url">{{ url }}</div>
        <el-button :icon="Download" type="primary" size="small" @click="downloadQr" style="margin-top:8px">
          下载 PNG
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { Link, CopyDocument, Picture, Position, Download } from '@element-plus/icons-vue'

const props = defineProps({
  label: { type: String, required: true },
  url: { type: String, required: true },
  /** 用于服务器侧 QR 生成。machineId 必填 */
  machineId: { type: [String, Number], default: 0 },
})

const qrOpen = ref(false)

const qrSrc = computed(() => {
  const encoded = encodeURIComponent(props.url)
  return `/api/devices/machines/${props.machineId}/qrcode/?url=${encoded}&size=600`
})

async function copy() {
  try {
    await navigator.clipboard.writeText(props.url)
    ElMessage.success('已复制')
  } catch (e) {
    ElMessage.error('复制失败，请手动复制')
  }
}

function showQr() {
  qrOpen.value = true
}

function openUrl() {
  window.open(props.url, '_blank')
}

async function downloadQr() {
  const resp = await fetch(qrSrc.value)
  const blob = await resp.blob()
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = `qr-${props.label}.png`
  document.body.appendChild(link)
  link.click()
  link.remove()
  setTimeout(() => URL.revokeObjectURL(link.href), 1000)
}
</script>

<style scoped>
.access-url-card { display: flex; flex-direction: column; gap: 6px; }
.url-row {
  display: flex; align-items: center; gap: 8px;
  padding: 8px 12px;
  background: var(--el-fill-color-light);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 8px;
}
.url-label {
  display: flex; align-items: center; gap: 5px;
  color: var(--el-text-color-secondary);
  font-size: 12px;
  flex-shrink: 0;
  min-width: 90px;
}
.url-text {
  flex: 1; min-width: 0;
  font-family: ui-monospace, Menlo, monospace;
  font-size: 13px;
  color: var(--el-color-primary);
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.qr-url {
  margin-top: 10px;
  font-family: ui-monospace, Menlo, monospace; font-size: 12px;
  color: var(--el-text-color-secondary); word-break: break-all;
}
</style>
