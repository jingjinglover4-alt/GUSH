import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const routes = [
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/Login.vue'),
    meta: { public: true }
  },
  {
    path: '/',
    component: () => import('@/views/Layout.vue'),
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'dashboard',
        component: () => import('@/views/Dashboard.vue'),
        meta: { title: '仪表盘', icon: 'DataLine' }
      },
      {
        path: 'devices',
        name: 'devices',
        component: () => import('@/views/devices/DeviceList.vue'),
        meta: { title: '设备管理', icon: 'Monitor' }
      },
      {
        path: 'devices-health',
        name: 'device-health',
        component: () => import('@/views/devices/DeviceHealth.vue'),
        meta: { title: '设备健康', icon: 'Cpu' }
      },
      {
        path: 'devices/:id',
        name: 'device-detail',
        component: () => import('@/views/devices/DeviceDetail.vue'),
        meta: { title: '设备详情', hidden: true }
      },
      {
        path: 'projects',
        name: 'projects',
        component: () => import('@/views/projects/ProjectList.vue'),
        meta: { title: '项目管理', icon: 'Files' }
      },
      {
        path: 'projects/:id',
        name: 'project-detail',
        component: () => import('@/views/projects/ProjectDetail.vue'),
        meta: { title: '项目详情', hidden: true }
      },
      {
        path: 'projects/:id/page-editor',
        name: 'page-editor',
        component: () => import('@/views/projects/PageEditor.vue'),
        meta: { title: '页面装修', hidden: true }
      },
      {
        path: 'projects/:id/leads',
        name: 'project-leads',
        component: () => import('@/views/projects/ProjectLeads.vue'),
        meta: { title: '用户获客', hidden: true }
      },
      {
        path: 'products',
        name: 'products',
        component: () => import('@/views/products/ProductList.vue'),
        meta: { title: '商品管理', icon: 'Box' }
      },
      {
        path: 'stock-movements',
        name: 'stock-movements',
        component: () => import('@/views/stock/StockMovements.vue'),
        meta: { title: '库存流水', icon: 'Tickets' }
      },
      {
        path: 'system/logs',
        name: 'system-logs',
        component: () => import('@/views/system/OperationLogs.vue'),
        meta: { title: '操作日志', icon: 'Document' }
      }
    ]
  },
  { path: '/:pathMatch(.*)*', redirect: '/' }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to) => {
  const auth = useAuthStore()
  if (!to.meta.public && !auth.isLoggedIn) {
    return { path: '/login', query: { redirect: to.fullPath } }
  }
  if (to.path === '/login' && auth.isLoggedIn) {
    return { path: '/' }
  }
})

export default router
