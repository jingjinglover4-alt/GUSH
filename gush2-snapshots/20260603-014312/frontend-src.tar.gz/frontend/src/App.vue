<template>
  <router-view />
</template>

<script setup>
// 全局根组件 - 仅承载路由出口
// 深色主题由 <html class="dark"> + Element Plus dark css-vars 提供
</script>
